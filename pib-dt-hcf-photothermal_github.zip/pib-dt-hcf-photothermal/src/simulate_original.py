"""Reduced-order physics-informed HCF photothermal Bayes twin, fully synthetic.
Python 3.11; requires numpy scipy matplotlib pandas. Fixed RNG seed 20261025.
All concentrations are ppm, signals mrad; results NOT experimental validation.
"""
import numpy as np, pandas as pd, matplotlib.pyplot as plt
from scipy.special import logsumexp
from scipy.stats import chi2
from pathlib import Path
RNG=np.random.default_rng(20261025)
OUT=Path(__file__).parent.parent/'data'/'original_reproduced'; OUT.mkdir(parents=True,exist_ok=True)  # revision: output folder only
FIG=Path(__file__).parent.parent/'figures'/'original';FIG.mkdir(parents=True,exist_ok=True)
H0=.016; SIG_ON=.026; SIG_OFF=.014; SIG_U=.018
T0=296.; F=1000.; TAU0=.00028; C2=1.438776877; NU0=6500.; ELOW=300.
W=10; onset=50; nsteps=120
modes=['normal','gas event','offset fault','gain fault']
prior=np.array([.7,.1,.1,.1]); scales=np.array([0.,30.,.14,.21])
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':140,'savefig.dpi':190})

def transfer(T):
    Q=(T/T0)**1.5
    S=1/Q*np.exp(-C2*ELOW*(1/T-1/T0))*((1-np.exp(-C2*NU0/T))/(1-np.exp(-C2*NU0/T0)))
    tau=TAU0*(T0/T)**.7
    den=np.sqrt(1+(2*np.pi*F*tau)**2)
    den0=np.sqrt(1+(2*np.pi*F*TAU0)**2)
    return S*den0/den

def make_episode(kind, rng):
    t=np.arange(nsteps)
    c0=rng.uniform(25,65); db=rng.uniform(.09,.17); dg=-rng.uniform(.16,.28); dc=rng.uniform(18,36)
    c=np.full(nsteps,c0); b=np.full(nsteps,rng.uniform(.04,.09)); ell=np.full(nsteps,rng.normal(0,.015))
    if kind in ('gas event','joint'):
        c[onset:96]+=dc
    if kind=='offset fault': b[onset:]+=db
    if kind in ('gain fault','joint'): ell[onset:]+=dg
    T=T0+rng.uniform(2,5)*np.sin(2*np.pi*t/91+rng.uniform(-1,1)) + rng.normal(0,.3,nsteps)
    A=transfer(T); cal=1+rng.normal(0,.015)
    y_off=b+rng.normal(0,SIG_OFF,nsteps)
    y_on=H0*cal*A*np.exp(ell)*c+b+rng.normal(0,SIG_ON,nsteps)
    y_u=ell+rng.normal(0,SIG_U,nsteps)
    return {'t':t,'kind':kind,'c':c,'b':b,'ell':ell,'T':T,'A':A,'y_on':y_on,'y_off':y_off,'u':y_u,'cal':cal,'c0':c0}

def features(d):
    return np.stack([(d['y_on']-d['y_off'])/d['A'], d['y_off'], d['u']],axis=1)

def contrast_cov(d,i0,i1,j0,j1):
    # contrasts across two W-frame sample means, observation noise covariance only
    ap=d['A'][i0:i1]; aq=d['A'][j0:j1]
    n1=len(ap); n2=len(aq)
    var1=(SIG_ON**2+SIG_OFF**2)*(np.sum(1/ap**2)/n1**2+np.sum(1/aq**2)/n2**2)
    cross=-(SIG_OFF**2)*(np.sum(1/ap)/n1**2+np.sum(1/aq)/n2**2)
    v2=SIG_OFF**2*(1/n1+1/n2); v3=SIG_U**2*(1/n1+1/n2)
    return np.array([[var1,cross,0],[cross,v2,0],[0,0,v3]])

def bayes_contrast(d,pre,post):
    x=features(d)
    i0,i1=pre; j0,j1=post
    delta=x[j0:j1].mean(axis=0)-x[i0:i1].mean(axis=0)
    Sigma=contrast_cov(d,i0,i1,j0,j1)
    c0=np.mean(x[i0:i1,0])/(H0*np.exp(np.mean(x[i0:i1,2])))
    g0=np.exp(np.mean(x[i0:i1,2]));
    V=np.array([[0,0,0],[H0*g0,0,0],[0,1,0],[H0*g0*c0,0,1.]]).T
    # col: normal, gas, offset, gain
    ll=np.zeros(4); mu=np.zeros(4); sd=np.zeros(4); chi=np.zeros(4)
    for m in range(4):
        C=Sigma+scales[m]**2*np.outer(V[:,m],V[:,m])
        sg,ld=np.linalg.slogdet(C)
        if sg<=0: raise ValueError('bad cov')
        ll[m]=-.5*(3*np.log(2*np.pi)+ld+delta@np.linalg.solve(C,delta))+np.log(prior[m])
        if m:
            iv=np.linalg.solve(Sigma,V[:,m]); postvar=1/(1/scales[m]**2 + V[:,m]@iv)
            mu[m]=postvar*(iv@delta);sd[m]=np.sqrt(postvar)
        chi[m]=(delta-V[:,m]*mu[m])@np.linalg.solve(Sigma,delta-V[:,m]*mu[m])
    posteriors=np.exp(ll-logsumexp(ll)); ix=int(np.argmax(posteriors))
    # A model that fails its 2 residual dimensions is not trusted; 99.5% null chi2 threshold
    reject=ix>0 and chi[ix]>chi2.ppf(.995,2)
    label='unmodelled' if reject else modes[ix]
    return {'p':posteriors,'label':label,'ix':ix,'d':delta,'mu':mu,'sd':sd,'chi':chi}

def other_classifiers(d,pre,post):
    x=features(d)
    da=np.mean(d['y_on'][post[0]:post[1]])-np.mean(d['y_on'][pre[0]:pre[1]])
    dd=np.mean(x[post[0]:post[1],0])-np.mean(x[pre[0]:pre[1],0])
    # detectors have matched approx 4-sigma per-contrast threshold, label nonzero as gas
    full='gas event' if abs(da)>4*np.sqrt(2/W)*SIG_ON else 'normal'
    differential='gas event' if abs(dd)>4*np.sqrt(2/W)*np.sqrt(SIG_ON**2+SIG_OFF**2) else 'normal'
    return full,differential

def estimates(d,start=75,stop=85):
    s=slice(start,stop);A=d['A'][s]; off=d['y_off'][s]; y=d['y_on'][s]; u=d['u'][s]
    c0=d['c0']
    # Calibration on known stable 0:25 segment, from all available data for baseline fairness.
    bcal=np.mean(d['y_off'][:25]);ucal=np.mean(d['u'][:25]);acal=np.mean(d['A'][:25])
    # on-only: offset and gain fixed from clean calibration
    naive=(y-bcal)/(H0*A*np.exp(ucal))
    diff=(y-off)/(H0*A*np.exp(ucal))
    # joint: use mean of physics-corrected differential, power-estimated gain
    # (small-signal per-frame estimator, average in a stable W-frame window)
    joint=(y-off)/(H0*A*np.exp(u))
    mu=np.array([np.mean(naive),np.mean(diff),np.mean(joint)])
    # independent point noises; optical channels and pump telemetry; calibration systematic
    cstar=np.mean(joint)
    sd1=SIG_ON/np.sqrt(len(y))*1/(H0*np.mean(A)*np.exp(ucal))
    sd2=np.sqrt(SIG_ON**2+SIG_OFF**2)/np.sqrt(len(y))*1/(H0*np.mean(A)*np.exp(ucal))
    sd3=np.sqrt((SIG_ON**2+SIG_OFF**2)/len(y)/(H0*np.mean(A)*np.exp(np.mean(u)))**2
                +(cstar*SIG_U/np.sqrt(len(y)))**2+(.015*cstar)**2)
    return mu,np.array([sd1,sd2,sd3])

# Monte Carlo quantitative benchmark: fixed windows pre-change 40:50 and post-change 52:62
N=140
rows=[]; detail=[]; case_ex={}
for k in modes+['joint']:
    for j in range(N):
        d=make_episode(k,RNG)
        if j==0:case_ex[k]=d
        bc=bayes_contrast(d,(40,50),(52,62))
        baselines=other_classifiers(d,(40,50),(52,62))
        est,sd=estimates(d)
        ct=np.mean(d['c'][75:85])
        row={'kind':k,'trial':j,'bayes':bc['label'],'single':baselines[0], 'differential':baselines[1],
             'correct':bc['label']==k,'postprob':bc['p'][bc['ix']], 'truth_ppm':ct,
             'naive':est[0], 'diff':est[1], 'twin':est[2],
             'naive_sd':sd[0], 'diff_sd':sd[1],'twin_sd':sd[2], 'chi2':bc['chi'][bc['ix']]}
        rows.append(row)
        if j<3: detail.append((k,j,bc['p'],bc['d']))
df=pd.DataFrame(rows);df.to_csv(OUT/'monte_carlo_trials.csv',index=False)

# label metrics: planned classes (exclude joint from standard confusion matrix)
planned=df[df.kind.isin(modes)].copy()
from sklearn.metrics import accuracy_score,f1_score, confusion_matrix
stats={}
for method in ['single','differential','bayes']:
    stats[method]={'accuracy':accuracy_score(planned.kind,planned[method]),
        'macro_f1':f1_score(planned.kind,planned[method],labels=modes,average='macro',zero_division=0),
        'false_alarm':np.mean(planned.loc[planned.kind=='normal',method]!='normal')}
quant=[]
for method in ['naive','diff','twin']:
    pred=df[method].values;true=df.truth_ppm.values;std=df[method+'_sd'].values
    quant.append(dict(method=method, RMSE_ppm=np.sqrt(np.mean((pred-true)**2)),
                      MAE_ppm=np.mean(np.abs(pred-true)), coverage_95=np.mean(np.abs(pred-true)<=1.96*std),
                      median_width_95=np.median(3.92*std)))
qdf=pd.DataFrame(quant)
bykind=[]
for k,g in df.groupby('kind',sort=False):
    for method in ['naive','diff','twin']:
        bykind.append({'scenario':k,'estimator':method,'RMSE_ppm':np.sqrt(np.mean((g[method]-g.truth_ppm)**2)),
              'coverage95':np.mean(abs(g[method]-g.truth_ppm)<=1.96*g[method+'_sd'])})
pd.DataFrame(bykind).to_csv(OUT/'scenario_metrics.csv',index=False)

# bootstrap paired uncertainty across trials (same data episodes)
b_rng=np.random.default_rng(20261026)
D=(df['diff']-df.truth_ppm).to_numpy()**2-(df['twin']-df.truth_ppm).to_numpy()**2
mean_boot=[]
for i in range(2000):
    idx=b_rng.integers(0,len(D),len(D));mean_boot.append(D[idx].mean())
ci=np.quantile(mean_boot,[.025,.975])

# Stress test transfer correction ablation: same cases, ignoring measured temperature correction
stress=[]
for k in modes+['joint']:
    dg=df[df.kind==k]
    stress.append({'scenario':k, 'Bayes_correct':(dg.bayes==k).mean(),'Joint_RMSE':np.sqrt(np.mean((dg.twin-dg.truth_ppm)**2))})

# Plot A pictorial hardware schematic, clean with matplotlib shapes
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle, Ellipse

def rounded(ax,x,y,w,h,title,subtitle='',fc='#E8F1FA',ec='#315D8B',fs=10):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.018,rounding_size=0.018',facecolor=fc,edgecolor=ec,linewidth=1.5))
    ax.text(x+w/2,y+h*.62,title,ha='center',va='center',fontsize=fs,fontweight='bold',color='#163A5A')
    if subtitle:ax.text(x+w/2,y+h*.25,subtitle,ha='center',va='center',fontsize=8,color='#325471')

def arrow(ax,x0,y0,x1,y1,col='#54728c',rad=0):
    ax.add_patch(FancyArrowPatch((x0,y0),(x1,y1),arrowstyle='-|>',mutation_scale=12,linewidth=1.7,color=col,connectionstyle=f'arc3,rad={rad}'))
fig,ax=plt.subplots(figsize=(11.6,4.1));ax.set_xlim(0,12);ax.set_ylim(0,4);ax.axis('off')
rounded(ax,.15,2.55,1.55,.8,'Pump laser','line-locked 1.53 µm',fc='#FCEDE5',ec='#B9673D')
rounded(ax,.15,1.23,1.55,.8,'Probe laser','1.55 µm',fc='#ECF7EE',ec='#3B8659')
rounded(ax,2.55,1.8,2.28,1.15,'Hollow-core AR fiber','gas-filled active cell',fc='#E3F4F2',ec='#26796E')
rounded(ax,5.58,1.95,1.88,.86,'Phase readout','on-line signal',fc='#E8F1FA')
rounded(ax,5.58,.62,1.88,.78,'Off-resonance','reference phase',fc='#F4F0FF',ec='#6C58A9')
rounded(ax,2.62,3.15,2.05,.63,'Pump monitor','log power telemetry',fc='#FCEDE5',ec='#B9673D')
rounded(ax,8.3,1.16,1.7,1.6,'Bayesian','digital twin',fc='#EDF3FF',ec='#3359B8')
rounded(ax,10.65,1.15,1.2,1.62,'Outputs','gas · fault\nCI · abstain',fc='#EEFAF1',ec='#3D9369')
arrow(ax,1.7,2.95,2.55,2.55,'#B9673D');arrow(ax,1.7,1.63,2.55,2.1,'#3B8659')
arrow(ax,4.83,2.4,5.58,2.39);arrow(ax,4.83,1.92,5.58,1.01,'#7D6AA7')
arrow(ax,1.05,3.35,2.62,3.48,'#B9673D');arrow(ax,4.67,3.48,8.48,2.75,'#B9673D')
arrow(ax,7.46,2.38,8.3,2.36);arrow(ax,7.46,1.03,8.3,1.52,'#7D6AA7')
arrow(ax,10.,1.96,10.65,1.96,'#338860')
ax.text(3.7,.55,'Independent evidence separates photothermal absorption, common-mode phase drift, and pump-loss faults',fontsize=8.8,ha='center',color='#475569')
fig.tight_layout();fig.savefig(FIG/'fig01_pictorial_setup.png',bbox_inches='tight');plt.close(fig)

# Flowchart
fig,ax=plt.subplots(figsize=(11,5.5));ax.set_xlim(0,11);ax.set_ylim(0,6);ax.axis('off')
rounded(ax,.3,4.88,2.45,.8,'Acquire 3 channels','on · off · pump')
rounded(ax,3.3,4.88,3.0,.8,'Physics normalizer','H(T,p,f) + gas line strength',fc='#E3F4F2',ec='#26796E')
rounded(ax,6.83,4.88,3.55,.8,'Sliding pre/post windows','correlated contrast + covariance',fc='#E8F1FA')
rounded(ax,6.83,3.15,3.55,.95,'Bayesian mode evidence','4 hypotheses + posterior odds',fc='#F3EEFE',ec='#7056A3')
rounded(ax,3.32,3.15,3.0,.95,'Physical identifiability','gas vs offset vs gain signatures',fc='#F3EEFE',ec='#7056A3')
rounded(ax,.25,3.15,2.52,.95,'Diagnostics gate','residual + uncertainty',fc='#FCEDE5',ec='#B9673D')
rounded(ax,.3,.95,2.6,1.,'Abstain / recalibrate','novel or coincident fault',fc='#FEF3E5',ec='#B9673D')
rounded(ax,4.02,.95,3.,1.,'Concentration posterior','mean + 95% interval',fc='#E8F6EA',ec='#388B61')
rounded(ax,8.,.95,2.6,1.,'Fault-event report','event · instrument · normal',fc='#E8F6EA',ec='#388B61')
arrow(ax,2.75,5.28,3.3,5.28);arrow(ax,6.3,5.28,6.83,5.28)
arrow(ax,8.6,4.88,8.6,4.1);arrow(ax,6.83,3.57,6.32,3.57)
arrow(ax,3.32,3.57,2.77,3.57);arrow(ax,1.51,3.15,1.51,1.95)
arrow(ax,2.77,3.15,4.62,1.95,'#358C6A');arrow(ax,9.18,3.15,9.18,1.95,'#358C6A')
ax.text(5.38,2.57,'if model adequate',ha='center',fontsize=8,color='#388B61')
ax.text(1.8,2.56,'if inconsistent',ha='center',fontsize=8,color='#A96831')
fig.tight_layout();fig.savefig(FIG/'fig02_algorithm_flow.png',bbox_inches='tight');plt.close(fig)

# Example time traces
ex=case_ex['gas event'];fx=case_ex['gain fault'];fo=case_ex['offset fault']
fig,axes=plt.subplots(3,1,figsize=(10.6,6.7),sharex=True)
for ax,key,title in zip(axes,[ex,fo,fx],['True gas excursion','Offset fault (no gas change)','Pump gain fault (no gas change)']):
    x=features(key);ax.plot(key['t'],x[:,0],lw=1.3,color='#1864AB',label='Physics-normalized differential phase')
    ax.plot(key['t'], x[:,1]*3,color='#D97706',lw=1.0,alpha=.82,label='Off-resonance reference × 3')
    ax.plot(key['t'], x[:,2],color='#8B5CF6',lw=1.,alpha=.85,label='Log pump power')
    ax.axvspan(onset,95,alpha=.09,color='#EF4444');ax.axvline(onset,color='#B91C1C',ls='--',lw=.9)
    ax.set_title(title,loc='left',fontweight='bold',fontsize=10);ax.set_ylabel('Normalized units')
axes[-1].set_xlabel('Acquisition index');axes[0].legend(ncol=3,loc='upper center',bbox_to_anchor=(.5,1.35),frameon=False,fontsize=8)
fig.subplots_adjust(hspace=.40,top=.87,bottom=.10,left=.09,right=.97)
fig.savefig(FIG/'fig03_mechanism_signatures.png',bbox_inches='tight');plt.close(fig)

# confusions
labs=modes
fig,axes=plt.subplots(1,3,figsize=(11.5,3.65))
for ax,(method,label) in zip(axes,[('single','Single on-line'),('differential','Off-ref. differential'),('bayes','Bayesian twin')]):
    mat=np.zeros((4,5))
    for i,actual in enumerate(labs):
        for j,pred in enumerate(labs+['unmodelled']):
            mat[i,j]=np.mean(planned.loc[planned.kind==actual,method]==pred)
    im=ax.imshow(mat,vmin=0,vmax=1,cmap='Blues');
    for i in range(4):
        for j in range(5):ax.text(j,i,f'{mat[i,j]*100:.0f}',ha='center',va='center',fontsize=8.7,color='white' if mat[i,j]>.55 else '#27384A')
    ax.set_xticks(range(5),['N','G','O','P','U']);ax.set_yticks(range(4),['N','G','O','P']);ax.set_title(label,fontsize=10,fontweight='bold');ax.set_xlabel('Predicted')
axes[0].set_ylabel('True class');fig.text(.5,-.005,'N: normal    G: gas event    O: offset fault    P: pump gain fault    U: unmodelled/reject       Row percentages',ha='center',fontsize=8)
fig.subplots_adjust(left=.065,right=.93,top=.88,bottom=.18,wspace=.25);fig.colorbar(im,ax=axes.ravel().tolist(),shrink=.78,pad=.016,label='Fraction')
fig.savefig(FIG/'fig04_confusions.png',bbox_inches='tight');plt.close(fig)

# RMSE and coverage
fig,ax=plt.subplots(figsize=(10,4.4));cases=modes+['joint'];xs=np.arange(5)
for jj,(method,color) in enumerate([('naive','#D97706'),('diff','#4678B4'),('twin','#1E8A6B')]):
    values=[]
    for k in cases:
        g=df[df.kind==k];values.append(np.sqrt(np.mean((g[method]-g.truth_ppm)**2)))
    ax.bar(xs+(jj-1)*.25,values,width=.23,color=color,label={'naive':'Fixed single channel','diff':'Differential only','twin':'Proposed twin'}[method])
ax.set_xticks(xs,['Normal','Gas event','Offset fault','Gain fault','Joint gas+gain']);ax.set_ylabel('Concentration RMSE (ppm)');ax.legend(frameon=False,ncol=3,loc='upper center',bbox_to_anchor=(.5,1.14));ax.grid(axis='y',alpha=.2)
fig.tight_layout();fig.savefig(FIG/'fig05_rmse_by_scenario.png',bbox_inches='tight');plt.close(fig)
fig,axes=plt.subplots(1,2,figsize=(11.0,4.0))
for m,col in [('naive','#D97706'),('diff','#4678B4'),('twin','#1E8A6B')]:
    err=df[m]-df.truth_ppm
    axes[0].hist(err,bins=np.linspace(-35,20,45),alpha=.45,color=col,label=m,density=True)
axes[0].axvline(0,color='#334155',lw=1.);axes[0].set_xlabel('Concentration error (ppm)');axes[0].set_ylabel('Probability density');axes[0].legend(frameon=False)
cover=[]
for kind in cases:
    g=df[df.kind==kind];cover.append([np.mean(abs(g[m]-g.truth_ppm)<=1.96*g[m+'_sd']) for m in ['naive','diff','twin']])
mat=np.array(cover);x=np.arange(len(cases));
for i,(name,col) in enumerate([('naive','#D97706'),('diff','#4678B4'),('twin','#1E8A6B')]): axes[1].plot(x,mat[:,i]*100,'o-',lw=1.5,ms=5,color=col,label=name)
axes[1].axhline(95,ls='--',color='black',lw=1.,label='nominal 95%');axes[1].set_ylim(0,105)
axes[1].set_xticks(x,['Normal','Gas','Offset','Gain','Joint']);axes[1].set_ylabel('Empirical 95% coverage (%)');axes[1].legend(frameon=False,fontsize=8);axes[1].grid(axis='y',alpha=.2)
fig.tight_layout();fig.savefig(FIG/'fig06_error_coverage.png',bbox_inches='tight');plt.close(fig)

# show 4 posterior mode probabilities in one representative kind each
fig,axes=plt.subplots(2,2,figsize=(10.7,6.0),sharex=True,sharey=True)
for ax,kind in zip(axes.flat,modes):
    d=case_ex[kind];arr=[];ts=[]
    for k in range(2*W-1,nsteps):
        r=bayes_contrast(d,(k-2*W+1,k-W+1),(k-W+1,k+1));arr.append(r['p']);ts.append(k)
    arr=np.array(arr);ts=np.array(ts)
    for m,co in enumerate(['#65758b','#2D8B6B','#D97706','#6751AE']): ax.plot(ts,arr[:,m],lw=1.45,label=modes[m],color=co)
    ax.axvline(50,ls='--',color='#AE243A',lw=1);ax.set_title(kind.title(),fontweight='bold',loc='left');ax.set_ylim(-.04,1.04)
axes[1,0].set_xlabel('Index of latest observation');axes[1,1].set_xlabel('Index of latest observation')
axes[0,0].set_ylabel('Posterior class probability');axes[1,0].set_ylabel('Posterior class probability')
axes[0,0].legend(ncol=4,loc='upper left',bbox_to_anchor=(0,1.36),frameon=False,fontsize=8)
fig.subplots_adjust(top=.88,bottom=.12,left=.09,right=.96,hspace=.33,wspace=.19)
fig.savefig(FIG/'fig07_posteriors.png',bbox_inches='tight');plt.close(fig)

# an illustrative replicate calibrated concentration trace with credible band; local W frame running
ed=case_ex['gain fault'];ests=[];lower=[];upper=[]; tt=[]
for end in range(10,nsteps):
    mu,sd=estimates(ed,end-10,end)
    ests.append(mu[2]);lower.append(mu[2]-1.96*sd[2]);upper.append(mu[2]+1.96*sd[2]);tt.append(end)
fig,ax=plt.subplots(figsize=(10.1,3.8));ax.plot(ed['t'],ed['c'],color='#243145',ls='--',lw=1.7,label='Simulated true gas concentration')
ax.plot(tt,ests,color='#1D7F69',lw=1.5,label='Posterior mean (local Gaussian approx.)');ax.fill_between(tt,lower,upper,color='#1D7F69',alpha=.17,label='Nominal 95% interval')
ax.axvspan(50,119,color='#B91C1C',alpha=.08,label='Pump gain fault active');ax.set_ylim(15,75);ax.set_xlabel('Acquisition index');ax.set_ylabel('Gas concentration (ppm)');ax.legend(frameon=False,loc='upper right',fontsize=8)
fig.tight_layout();fig.savefig(FIG/'fig08_concentration_trace.png',bbox_inches='tight');plt.close(fig)

# Write exact reported summary
with open(OUT/'results_summary.txt','w') as f:
    f.write('All values below are from deterministic synthetic Monte Carlo seed=20261025. Not laboratory data.\n')
    f.write(f'N={N} per class, {len(df)} episodes total; {len(planned)} planned-mode episodes.\n\n')
    f.write('CLASSIFICATION METRICS\n');f.write(pd.DataFrame(stats).T.to_string(float_format=lambda x:f'{x:.4f}')+'\n')
    f.write('\nQUANTIFICATION METRICS\n');f.write(qdf.to_string(index=False,float_format=lambda x:f'{x:.4f}')+'\n')
    f.write(f'\nPaired mean squared error gain of twin vs differential, ppm² = {D.mean():.4f}; bootstrap percentile 95% CI= [{ci[0]:.4f}, {ci[1]:.4f}]\n')
    f.write('\nBY SCENARIO\n');f.write(pd.DataFrame(bykind).to_string(index=False,float_format=lambda x:f'{x:.3f}')+'\n')
    f.write('\nREJECTION ON JOINT CASE\n');f.write(str(df[df.kind=='joint'].bayes.value_counts().to_dict())+'\n')
    f.write('\nMODES POSTERIOR CORRECT CLASS RATE\n');f.write(str(planned.groupby('kind').correct.mean().to_dict())+'\n')
print(open(OUT/'results_summary.txt').read())
