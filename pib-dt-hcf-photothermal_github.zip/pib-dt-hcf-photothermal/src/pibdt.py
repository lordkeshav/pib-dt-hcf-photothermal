"""PIB-DT extended simulation engine.

Re-implements the functions of the supplied simulate.py with explicit options so
that (i) the default configuration reproduces the original benchmark bit-for-bit
and (ii) ablations, sensitivity sweeps, an exact (non-linearised) gain evidence,
and additional baselines can be evaluated on the same synthetic data-generating
process.  All results are synthetic; nothing here is laboratory data.
"""
from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field, replace
from scipy.special import logsumexp
from scipy.stats import chi2
from scipy.optimize import minimize_scalar

MODES = ['normal', 'gas event', 'offset fault', 'gain fault']
KINDS = MODES + ['joint']
C2 = 1.438776877          # second radiation constant, cm K
GH_X, GH_W = np.polynomial.hermite.hermgauss(80)


@dataclass
class Cfg:
    H0: float = .016
    SIG_ON: float = .026
    SIG_OFF: float = .014
    SIG_U: float = .018
    noise_mult: float = 1.0          # multiplies all three noise SDs (truth and model)
    T0: float = 296.
    F: float = 1000.
    TAU0: float = .00028
    NU0: float = 6500.
    ELOW: float = 300.
    ELOW_model: float | None = None  # E'' assumed by the twin (None = exact)
    temp_amp: tuple = (2., 5.)       # sinusoidal temperature excursion range, K
    temp_meas_sd: float = 0.0        # extra temperature-sensor error seen by twin, K
    W: int = 10
    onset: int = 50
    nsteps: int = 120
    prior: tuple = (.7, .1, .1, .1)
    scales: tuple = (0., 30., .14, .21)
    cal_sd_true: float = .015
    cal_sd_model: float = .015
    amp_scale: dict = field(default_factory=lambda: {'gas': 1., 'offset': 1., 'gain': 1.})
    evidence: str = 'linear'         # 'linear' (original) or 'exact' (Gauss-Hermite)
    cov: str = 'full'                # 'full' or 'diag'
    temp_norm: bool = True           # physics normalisation by A_k
    channels: str = 'all'            # 'all', 'no_ref', 'no_pump'
    gate_alpha: float = .995
    gate: bool = True
    pre: tuple = (40, 50)
    post: tuple = (52, 62)
    est_win: tuple = (75, 85)

    @property
    def s(self):
        m = self.noise_mult
        return self.SIG_ON * m, self.SIG_OFF * m, self.SIG_U * m


def transfer(T, c: Cfg, elow=None):
    elow = c.ELOW if elow is None else elow
    Q = (T / c.T0) ** 1.5
    S = 1 / Q * np.exp(-C2 * elow * (1 / T - 1 / c.T0)) * ((1 - np.exp(-C2 * c.NU0 / T)) / (1 - np.exp(-C2 * c.NU0 / c.T0)))
    tau = c.TAU0 * (c.T0 / T) ** .7
    den = np.sqrt(1 + (2 * np.pi * c.F * tau) ** 2)
    den0 = np.sqrt(1 + (2 * np.pi * c.F * c.TAU0) ** 2)
    return S * den0 / den


def make_episode(kind, rng, c: Cfg, rng_extra=None):
    """Same draw order as the original simulate.py (bit-exact at defaults)."""
    s_on, s_off, s_u = c.s
    n = c.nsteps; t = np.arange(n)
    c0 = rng.uniform(25, 65); db = rng.uniform(.09, .17); dg = -rng.uniform(.16, .28); dc = rng.uniform(18, 36)
    db *= c.amp_scale['offset']; dg *= c.amp_scale['gain']; dc *= c.amp_scale['gas']
    conc = np.full(n, c0); b = np.full(n, rng.uniform(.04, .09)); ell = np.full(n, rng.normal(0, .015))
    if kind in ('gas event', 'joint'):
        conc[c.onset:96] += dc
    if kind == 'offset fault':
        b[c.onset:] += db
    if kind in ('gain fault', 'joint'):
        ell[c.onset:] += dg
    T = c.T0 + rng.uniform(*c.temp_amp) * np.sin(2 * np.pi * t / 91 + rng.uniform(-1, 1)) + rng.normal(0, .3, n)
    A = transfer(T, c)
    cal = 1 + rng.normal(0, .015) * (c.cal_sd_true / .015 if c.cal_sd_true else 0.0)
    y_off = b + rng.normal(0, s_off, n)
    y_on = c.H0 * cal * A * np.exp(ell) * conc + b + rng.normal(0, s_on, n)
    y_u = ell + rng.normal(0, s_u, n)
    # model-side transfer (what the twin believes)
    if c.temp_meas_sd > 0 or c.ELOW_model is not None:
        r = rng_extra if rng_extra is not None else np.random.default_rng(0)
        Tm = T + r.normal(0, c.temp_meas_sd, n) if c.temp_meas_sd > 0 else T
        A_hat = transfer(Tm, c, elow=c.ELOW_model)
    else:
        A_hat = A
    if not c.temp_norm:
        A_hat = np.ones(n)
    return dict(t=t, kind=kind, c=conc, b=b, ell=ell, T=T, A=A, A_hat=A_hat, y_on=y_on, y_off=y_off,
                u=y_u, cal=cal, c0=c0, dc=dc, db=db, dg=dg)


def features(d):
    A = d['A_hat']
    return np.stack([(d['y_on'] - d['y_off']) / A, d['y_off'], d['u']], axis=1)


def contrast_cov(d, c: Cfg, pre, post):
    s_on, s_off, s_u = c.s
    i0, i1 = pre; j0, j1 = post
    ap = d['A_hat'][i0:i1]; aq = d['A_hat'][j0:j1]
    n1 = len(ap); n2 = len(aq)
    var1 = (s_on ** 2 + s_off ** 2) * (np.sum(1 / ap ** 2) / n1 ** 2 + np.sum(1 / aq ** 2) / n2 ** 2)
    cross = -(s_off ** 2) * (np.sum(1 / ap) / n1 ** 2 + np.sum(1 / aq) / n2 ** 2)
    v2 = s_off ** 2 * (1 / n1 + 1 / n2); v3 = s_u ** 2 * (1 / n1 + 1 / n2)
    S = np.array([[var1, cross, 0], [cross, v2, 0], [0, 0, v3]])
    if c.cov == 'diag':
        S = np.diag(np.diag(S))
    return S


def _reduced(d, c: Cfg, pre, post):
    """Contrast vector, covariance and signature matrix for the chosen channel set."""
    s_on, s_off, s_u = c.s
    i0, i1 = pre; j0, j1 = post
    x = features(d)
    if c.channels == 'no_ref':           # on-line phase (A-normalised) and pump only
        A = d['A_hat']
        x = np.stack([d['y_on'] / A, d['u']], axis=1)
    delta = x[j0:j1].mean(axis=0) - x[i0:i1].mean(axis=0)
    if c.channels == 'all':
        Sigma = contrast_cov(d, c, pre, post)
        g0 = np.exp(np.mean(x[i0:i1, 2]))
        c0 = np.mean(x[i0:i1, 0]) / (c.H0 * g0)
        V = np.array([[0, 0, 0], [c.H0 * g0, 0, 0], [0, 1, 0], [c.H0 * g0 * c0, 0, 1.]]).T
        gain_fun = lambda a: np.array([c.H0 * g0 * c0 * (np.exp(a) - 1), 0., a])
    elif c.channels == 'no_pump':        # differential + reference, gain unobserved (g0 = 1 assumed)
        S3 = contrast_cov(d, c, pre, post)
        Sigma = S3[:2, :2]; delta = delta[:2]
        g0 = 1.0; c0 = np.mean(x[i0:i1, 0]) / c.H0
        V = np.array([[0, 0], [c.H0 * g0, 0], [0, 1], [c.H0 * g0 * c0, 0.]]).T
        gain_fun = lambda a: np.array([c.H0 * g0 * c0 * (np.exp(a) - 1), 0.])
    elif c.channels == 'no_ref':
        ap = d['A_hat'][i0:i1]; aq = d['A_hat'][j0:j1]
        n1, n2 = len(ap), len(aq)
        v1 = s_on ** 2 * (np.sum(1 / ap ** 2) / n1 ** 2 + np.sum(1 / aq ** 2) / n2 ** 2)
        v3 = s_u ** 2 * (1 / n1 + 1 / n2)
        Sigma = np.diag([v1, v3])
        g0 = np.exp(np.mean(x[i0:i1, 1]))
        c0 = (np.mean(x[i0:i1, 0])) / (c.H0 * g0)   # offset unknown -> biased plug-in
        Abar = np.mean(d['A_hat'][j0:j1])
        V = np.array([[0, 0], [c.H0 * g0, 0], [1 / Abar, 0], [c.H0 * g0 * c0, 1.]]).T
        gain_fun = lambda a: np.array([c.H0 * g0 * c0 * (np.exp(a) - 1), a])
    if c.cov == 'diag':
        Sigma = np.diag(np.diag(Sigma))
    return delta, Sigma, V, gain_fun


def _lognorm(r, Sinv, logdet, k):
    return -.5 * (k * np.log(2 * np.pi) + logdet + r @ Sinv @ r)


def bayes_contrast(d, c: Cfg, pre=None, post=None):
    pre = pre or c.pre; post = post or c.post
    delta, Sigma, V, gain_fun = _reduced(d, c, pre, post)
    k = len(delta)
    prior = np.array(c.prior); scales = np.array(c.scales)
    ll = np.zeros(4); mu = np.zeros(4); sd = np.zeros(4); chi = np.zeros(4)
    Sinv = np.linalg.inv(Sigma); _, ldS = np.linalg.slogdet(Sigma)
    for m in range(4):
        if c.evidence == 'exact' and m == 3:
            # exact non-linear gain signature, amplitude marginalised by Gauss-Hermite quadrature
            a_nodes = np.sqrt(2) * scales[3] * GH_X
            lw = np.log(GH_W / np.sqrt(np.pi))
            lls = np.array([_lognorm(delta - gain_fun(a), Sinv, ldS, k) for a in a_nodes])
            ll[m] = logsumexp(lls + lw) + np.log(prior[m])
            f = lambda a: .5 * (delta - gain_fun(a)) @ Sinv @ (delta - gain_fun(a)) + .5 * a * a / scales[3] ** 2
            res = minimize_scalar(f, bounds=(-2.5, 2.5), method='bounded', options={'xatol': 1e-8})
            mu[m] = res.x
            r = delta - gain_fun(mu[m]); chi[m] = r @ Sinv @ r
            # Laplace SD
            h = 1e-4; sd[m] = np.sqrt(1 / max((f(mu[m] + h) - 2 * f(mu[m]) + f(mu[m] - h)) / h ** 2, 1e-12))
            continue
        C = Sigma + scales[m] ** 2 * np.outer(V[:, m], V[:, m])
        sg, ld = np.linalg.slogdet(C)
        ll[m] = -.5 * (k * np.log(2 * np.pi) + ld + delta @ np.linalg.solve(C, delta)) + np.log(prior[m])
        if m:
            iv = np.linalg.solve(Sigma, V[:, m]); postvar = 1 / (1 / scales[m] ** 2 + V[:, m] @ iv)
            mu[m] = postvar * (iv @ delta); sd[m] = np.sqrt(postvar)
        chi[m] = (delta - V[:, m] * mu[m]) @ np.linalg.solve(Sigma, delta - V[:, m] * mu[m])
    post_p = np.exp(ll - logsumexp(ll)); ix = int(np.argmax(post_p))
    reject = c.gate and ix > 0 and chi[ix] > chi2.ppf(c.gate_alpha, k - 1)
    label = 'unmodelled' if reject else MODES[ix]
    return dict(p=post_p, label=label, ix=ix, d=delta, mu=mu, sd=sd, chi=chi, Sigma=Sigma, V=V)


def threshold_classifiers(d, c: Cfg, pre=None, post=None):
    pre = pre or c.pre; post = post or c.post
    s_on, s_off, _ = c.s; W = pre[1] - pre[0]
    x = features(d)
    da = np.mean(d['y_on'][post[0]:post[1]]) - np.mean(d['y_on'][pre[0]:pre[1]])
    dd = np.mean(x[post[0]:post[1], 0]) - np.mean(x[pre[0]:pre[1], 0])
    full = 'gas event' if abs(da) > 4 * np.sqrt(2 / W) * s_on else 'normal'
    diff = 'gas event' if abs(dd) > 4 * np.sqrt(2 / W) * np.sqrt(s_on ** 2 + s_off ** 2) else 'normal'
    return full, diff


def glr_classifier(d, c: Cfg, pre=None, post=None, alpha=.995):
    """Classical generalised-likelihood-ratio structured-residual isolation (no priors, no gate)."""
    pre = pre or c.pre; post = post or c.post
    delta, Sigma, V, _ = _reduced(d, c, pre, post)
    Si = np.linalg.inv(Sigma)
    T2 = delta @ Si @ delta
    if T2 <= chi2.ppf(alpha, len(delta)):
        return 'normal'
    lam = [(V[:, m] @ Si @ delta) ** 2 / (V[:, m] @ Si @ V[:, m]) for m in (1, 2, 3)]
    return MODES[1 + int(np.argmax(lam))]


def ml_features(d, c: Cfg, pre=None, post=None):
    pre = pre or c.pre; post = post or c.post
    delta, Sigma, V, _ = _reduced(d, c, pre, post)
    x = features(d); i0, i1 = pre
    c0 = np.mean(x[i0:i1, 0]) / (c.H0 * np.exp(np.mean(x[i0:i1, 2])))
    return np.r_[delta / np.sqrt(np.diag(Sigma)), c0]


def estimates(d, c: Cfg, start=None, stop=None, include_cal=True, include_pump=True):
    s_on, s_off, s_u = c.s
    start = start if start is not None else c.est_win[0]; stop = stop if stop is not None else c.est_win[1]
    s = slice(start, stop); A = d['A_hat'][s]; off = d['y_off'][s]; y = d['y_on'][s]; u = d['u'][s]
    bcal = np.mean(d['y_off'][:25]); ucal = np.mean(d['u'][:25])
    naive = (y - bcal) / (c.H0 * A * np.exp(ucal))
    diff = (y - off) / (c.H0 * A * np.exp(ucal))
    joint = (y - off) / (c.H0 * A * np.exp(u))
    mu = np.array([np.mean(naive), np.mean(diff), np.mean(joint)])
    cstar = np.mean(joint); n = len(y)
    sd1 = s_on / np.sqrt(n) / (c.H0 * np.mean(A) * np.exp(ucal))
    sd2 = np.sqrt(s_on ** 2 + s_off ** 2) / np.sqrt(n) / (c.H0 * np.mean(A) * np.exp(ucal))
    v3 = (s_on ** 2 + s_off ** 2) / n / (c.H0 * np.mean(A) * np.exp(np.mean(u))) ** 2
    if include_pump:
        v3 += (cstar * s_u / np.sqrt(n)) ** 2
    if include_cal:
        v3 += (c.cal_sd_model * cstar) ** 2
    return mu, np.array([sd1, sd2, np.sqrt(v3)])


def run_benchmark(c: Cfg, seed=20261025, N=140, kinds=KINDS, extra_seed=None, keep=False):
    """Returns list of per-episode dict rows (same order/draws as original when c is default)."""
    import pandas as pd
    rng = np.random.default_rng(seed)
    rx = np.random.default_rng(extra_seed if extra_seed is not None else seed + 7)
    rows = []; eps = {}
    for k in kinds:
        for j in range(N):
            d = make_episode(k, rng, c, rx)
            if keep and j == 0:
                eps[k] = d
            bc = bayes_contrast(d, c)
            s1, s2 = threshold_classifiers(d, c)
            est, sd = estimates(d, c)
            ct = np.mean(d['c'][c.est_win[0]:c.est_win[1]])
            rows.append(dict(kind=k, trial=j, bayes=bc['label'], single=s1, differential=s2,
                             glr=glr_classifier(d, c), correct=bc['label'] == k, postprob=bc['p'][bc['ix']],
                             truth_ppm=ct, naive=est[0], diff=est[1], twin=est[2], naive_sd=sd[0],
                             diff_sd=sd[1], twin_sd=sd[2], chi2=bc['chi'][bc['ix']], top=MODES[bc['ix']],
                             dc=d['dc'], db=d['db'], dg=d['dg'], **{f'p_{m}': bc['p'][i] for i, m in enumerate(MODES)}))
    df = pd.DataFrame(rows)
    return (df, eps) if keep else df


def class_metrics(df, col):
    from sklearn.metrics import accuracy_score, f1_score
    p = df[df.kind.isin(MODES)]
    return dict(accuracy=accuracy_score(p.kind, p[col]),
                macro_f1=f1_score(p.kind, p[col], labels=MODES, average='macro', zero_division=0),
                false_alarm=np.mean(p.loc[p.kind == 'normal', col] != 'normal'),
                joint_reject=np.mean(df.loc[df.kind == 'joint', col] == 'unmodelled') if (df.kind == 'joint').any() else np.nan)


def quant_metrics(df, m):
    e = df[m] - df.truth_ppm
    return dict(RMSE=np.sqrt(np.mean(e ** 2)), MAE=np.mean(np.abs(e)),
                coverage=np.mean(np.abs(e) <= 1.96 * df[m + '_sd']), width=np.median(3.92 * df[m + '_sd']))
