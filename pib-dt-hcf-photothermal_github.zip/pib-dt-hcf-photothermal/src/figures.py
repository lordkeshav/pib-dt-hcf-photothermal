"""Publication figures for the revised PIB-DT manuscript (600-dpi PNG + vector PDF)."""
import sys, json
import os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from pibdt import *
from pibdt import _reduced

R = os.path.join(HERE, '..', 'data', 'results'); F = os.path.join(HERE, '..', 'figures')
os.makedirs(F, exist_ok=True)
BLUE, ORANGE, AQUA, VIOLET, GRAY = '#2a78d6', '#eb6834', '#1baf7a', '#6250d6', '#8a8985'
INK, INK2, GRID = '#0b0b0b', '#52514e', '#e4e3df'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8, 'axes.titlesize': 8.5, 'axes.labelsize': 8,
                     'xtick.labelsize': 7.5, 'ytick.labelsize': 7.5, 'legend.fontsize': 7.2, 'axes.edgecolor': INK2,
                     'axes.labelcolor': INK, 'xtick.color': INK2, 'ytick.color': INK2, 'axes.spines.top': False,
                     'axes.spines.right': False, 'axes.linewidth': .7, 'lines.linewidth': 1.6, 'savefig.dpi': 600,
                     'pdf.fonttype': 42, 'axes.titleweight': 'bold', 'axes.titlelocation': 'left'})
W2 = 7.0  # double-column width, inches


def save(fig, name):
    fig.savefig(f'{F}/{name}.png', bbox_inches='tight', facecolor='white')
    fig.savefig(f'{F}/{name}.pdf', bbox_inches='tight', facecolor='white')
    plt.close(fig)


def grid(ax):
    ax.grid(axis='y', color=GRID, lw=.6); ax.set_axisbelow(True)


def box(ax, x, y, w, h, t, s='', fc='#eef4fb', ec=BLUE, fs=7.4):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.02,rounding_size=0.05', fc=fc, ec=ec, lw=1.1))
    ax.text(x + w / 2, y + h * (.63 if s else .5), t, ha='center', va='center', fontsize=fs, weight='bold', color=INK)
    if s: ax.text(x + w / 2, y + h * .28, s, ha='center', va='center', fontsize=6.8, color=INK2)


def arr(ax, a, b, c=INK2, rad=0, ls='-'):
    ax.add_patch(FancyArrowPatch(a, b, arrowstyle='-|>', mutation_scale=9, lw=1.0, color=c, ls=ls, connectionstyle=f'arc3,rad={rad}'))


# ---------------------------------------------------------------- Fig 1 architecture
fig, ax = plt.subplots(figsize=(W2, 3.0)); ax.set_xlim(0, 17); ax.set_ylim(0, 6.2); ax.axis('off')
box(ax, .1, 4.2, 2.8, 1.1, 'Pump laser', 'line-locked, modulated', '#fdf0ea', ORANGE)
box(ax, .1, 1.3, 2.8, 1.1, 'Probe laser', 'non-absorbed λs', '#e8f6f0', AQUA)
box(ax, 3.8, 2.5, 3.4, 1.5, 'Gas-filled HC-ARF', 'photothermal phase\nΔϕ ∝ h0·A·exp(ℓ)·c', '#eef4fb', BLUE)
box(ax, 3.8, 4.75, 3.4, 1.1, 'Pump-monitor tap', 'y3 = ℓ + ε3', '#fdf0ea', ORANGE)
box(ax, 8.1, 3.15, 3.0, 1.1, 'On-line readout', 'y1 = h0·A·e^ℓ·c + b + ε1', '#eef4fb', BLUE)
box(ax, 8.1, 1.65, 3.0, 1.1, 'Off-line reference', 'y2 = b + ε2', '#f1effb', VIOLET)
box(ax, 8.1, .15, 3.0, 1.1, 'Temperature sensor', 'A_k = A(T_k), Eqs. (4)–(6)', '#f4f4f2', GRAY)
box(ax, 12.0, 1.3, 2.5, 3.2, 'PIB-DT', 'contrast d, Σ\nmode evidence\nadequacy gate\nc̄ and V_c', '#eef4fb', BLUE)
box(ax, 15.0, 1.3, 1.9, 3.2, 'Output', 'cause label\nor abstain;\n95% interval', '#f4f4f2', INK2)
arr(ax, (2.9, 4.6), (3.8, 3.6), ORANGE); arr(ax, (2.9, 1.9), (3.8, 2.9), AQUA); arr(ax, (1.5, 5.3), (3.8, 5.3), ORANGE)
arr(ax, (7.2, 3.5), (8.1, 3.7)); arr(ax, (7.2, 2.9), (8.1, 2.2), VIOLET); arr(ax, (7.2, 5.3), (12.6, 4.5), ORANGE, rad=-.12)
arr(ax, (11.1, 3.7), (12.0, 3.4)); arr(ax, (11.1, 2.2), (12.0, 2.5), VIOLET); arr(ax, (11.1, .7), (12.0, 1.6), GRAY)
arr(ax, (14.5, 2.9), (15.0, 2.9))
ax.text(5.5, 1.55, 'c, b and ℓ act on different\nsubsets of (y1, y2, y3)', ha='center', fontsize=6.6, color=INK2, style='italic')
save(fig, 'Fig01_architecture')

# ---------------------------------------------------------------- Fig 2 flowchart
fig, ax = plt.subplots(figsize=(W2, 3.4)); ax.set_xlim(0, 15); ax.set_ylim(0, 6.6); ax.axis('off')
row = [(.1, 'Acquire', 'y1, y2, y3, T'), (3.1, 'Normalise', 'x_k, Eq. (11)'), (6.1, 'Contrast', 'd_k, Σ_k, Eq. (13)'),
       (9.1, 'Signatures', 'v_g, v_b, s_ℓ(a)'), (12.1, 'Evidence', 'P(M_m | d), Eq. (17)')]
for x, t, s in row: box(ax, x, 5.0, 2.7, 1.1, t, s)
for i in range(4): arr(ax, (row[i][0] + 2.7, 5.55), (row[i + 1][0], 5.55))
box(ax, 12.1, 2.9, 2.7, 1.2, 'MAP mode m*', 'largest posterior', '#f1effb', VIOLET)
arr(ax, (13.45, 5.0), (13.45, 4.1))
box(ax, 8.2, 2.9, 3.0, 1.2, 'Adequacy gate', 'Q* > χ²(k−1; α) ?', '#fdf0ea', ORANGE)
arr(ax, (12.1, 3.5), (11.2, 3.5))
box(ax, 5.0, .3, 3.0, 1.3, 'Cause report', 'label + posterior', '#e8f6f0', AQUA)
box(ax, 9.3, .3, 3.0, 1.3, 'Abstain', '"unmodelled"', '#fdf0ea', ORANGE)
box(ax, .3, 2.7, 3.6, 1.5, 'Calibrated inverse', 'ĉ_k, Eq. (21)\nc̄ ± 1.96√V_c, Eq. (22)', '#e8f6f0', AQUA)
arr(ax, (9.0, 2.9), (7.2, 1.6), AQUA); ax.text(7.6, 2.4, 'pass', fontsize=7, color=INK2)
arr(ax, (10.2, 2.9), (10.6, 1.6), ORANGE); ax.text(10.55, 2.25, 'fail', fontsize=7, color=INK2)
arr(ax, (3.6, 5.0), (2.6, 4.2), AQUA)
arr(ax, (2.1, 2.7), (5.0, .95), AQUA, ls='--'); arr(ax, (3.2, 2.7), (9.3, 1.2), AQUA, ls='--', rad=.15)
ax.text(.3, .8, 'interval reported on both\nbranches (caution flag on abstain)', fontsize=6.4, color=INK2)
save(fig, 'Fig02_flowchart')

# ---------------------------------------------------------------- data
lin = pd.read_csv(f'{R}/E1_main_linear_episodes.csv'); ex = pd.read_csv(f'{R}/E1_main_exact_episodes.csv')
_, eps = run_benchmark(Cfg(), keep=True)
EX = Cfg(evidence='exact')

# ---------------------------------------------------------------- Fig 3 signatures
fig, axes = plt.subplots(3, 1, figsize=(W2, 4.6), sharex=True)
for ax, k, t in zip(axes, ['gas event', 'offset fault', 'gain fault'], ['(a) Gas-concentration step', '(b) Common-mode offset fault (no gas change)', '(c) Effective pump-gain fault (no gas change)']):
    d = eps[k]; x = features(d)
    ax.plot(d['t'], x[:, 0], color=BLUE, lw=1.2, label='x₁: normalised differential phase (mrad)')
    ax.plot(d['t'], 3 * x[:, 1], color=VIOLET, lw=1.0, label='3·x₂: off-resonance reference (mrad, ×3)')
    ax.plot(d['t'], x[:, 2], color=ORANGE, lw=1.0, label='x₃: log pump power (–)')
    ax.axvspan(50, 95 if k == 'gas event' else 119, color=GRAY, alpha=.12, lw=0); ax.axvline(50, color=INK2, ls='--', lw=.8)
    for s0, s1 in [(40, 50), (52, 62)]: ax.axvspan(s0, s1, ymin=0, ymax=.05, color=INK2, alpha=.6, lw=0)
    ax.set_title(t); grid(ax)
axes[1].set_ylabel('Channel value')
axes[-1].set_xlabel('Acquisition index k'); axes[0].legend(ncol=3, loc='lower left', bbox_to_anchor=(0, 1.13), frameon=False)
fig.subplots_adjust(hspace=.45)
save(fig, 'Fig03_signatures')

# ---------------------------------------------------------------- Fig 4 contrast geometry (whitened)
rows = []
rng = np.random.default_rng(20261025)
for k in KINDS:
    for j in range(140):
        d = make_episode(k, rng, Cfg()); delta, Sigma, V, gf = _reduced(d, Cfg(), (40, 50), (52, 62))
        z = delta / np.sqrt(np.diag(Sigma)); rows.append((k, *z))
Z = pd.DataFrame(rows, columns=['kind', 'z1', 'z2', 'z3'])
fig, axes = plt.subplots(1, 3, figsize=(W2, 2.45))
cm = {'normal': GRAY, 'gas event': BLUE, 'offset fault': ORANGE, 'gain fault': AQUA}
mk = {'normal': 'o', 'gas event': 's', 'offset fault': '^', 'gain fault': 'D'}
for ax, (a, b, ttl) in zip(axes[:2], [('z1', 'z3', '(a) Differential vs pump'), ('z1', 'z2', '(b) Differential vs reference')]):
    for k in MODES:
        g = Z[Z.kind == k]; ax.scatter(g[a], g[b], s=9, marker=mk[k], color=cm[k], edgecolor='white', lw=.3, label=k, alpha=.9)
    ax.axhline(0, color=GRID, lw=.6); ax.axvline(0, color=GRID, lw=.6)
    ax.set_xlabel(f'Standardised contrast {a.replace("z", "d")}'); ax.set_ylabel(f'Standardised contrast {b.replace("z", "d")}'); ax.set_title(ttl)
axes[1].legend(frameon=False, loc='upper right', fontsize=6.6, markerscale=1.3, handletextpad=.2)
ax = axes[2]
for k in MODES:
    g = Z[Z.kind == k]; ax.scatter(g.z1, g.z3, s=7, color='#d6d5d0', edgecolor='none')
g = Z[Z.kind == 'joint']; ax.scatter(g.z1, g.z3, s=11, marker='x', color=INK, lw=.8, label='joint gas + gain')
ax.set_xlabel('Standardised contrast d1'); ax.set_ylabel('Standardised contrast d3'); ax.set_title('(c) Compound case off all rays')
ax.legend(frameon=False, loc='center right', fontsize=6.6)
fig.tight_layout(w_pad=1.2)
save(fig, 'Fig04_contrast_geometry')

# ---------------------------------------------------------------- Fig 5 confusion matrices
_c = pd.read_csv(f'{R}/T_confusion.csv')
conf = {m: [[float(_c[(_c.method == m) & (_c.true_class == t) & (_c.predicted_class == p)].fraction.iloc[0]) for p in MODES + ['unmodelled']] for t in MODES] for m in _c.method.unique()}
show = [('Fixed on-line threshold', '(a) On-line'), ('Reference-differential threshold', '(b) Differential'),
        ('GLR structured residual', '(c) GLR'), ('PIB-DT (linearised, original)', '(d) PIB-DT lin.'),
        ('PIB-DT (exact gain evidence)', '(e) PIB-DT exact')]
fig, axes = plt.subplots(1, 5, figsize=(W2, 1.95))
from matplotlib.colors import LinearSegmentedColormap
cmap = LinearSegmentedColormap.from_list('b', ['#fcfcfb', '#cfe0f5', '#7aa9e6', '#2a78d6', '#164a8f'])
for ax, (key, ttl) in zip(axes, show):
    m = np.array(conf[key]); im = ax.imshow(m, vmin=0, vmax=1, cmap=cmap)
    for i in range(4):
        for j in range(5):
            ax.text(j, i, f'{m[i, j] * 100:.0f}', ha='center', va='center', fontsize=6.6, color='white' if m[i, j] > .55 else INK)
    ax.set_xticks(range(5), ['N', 'G', 'O', 'P', 'U']); ax.set_yticks(range(4), ['N', 'G', 'O', 'P'] if ax is axes[0] else [''] * 4)
    ax.set_title(ttl, fontsize=7); ax.tick_params(length=0)
    for s in ax.spines.values(): s.set_visible(False)
axes[0].set_ylabel('True class'); axes[2].set_xlabel('Predicted class (row %)')
save(fig, 'Fig05_confusion')

# ---------------------------------------------------------------- Fig 6 recall vs SNR
amp = pd.read_csv(f'{R}/E4_amplitude_sweep.csv')
bins = np.array([0, 1, 2, 3, 4, 5, 6, 8, 10, 14, 20, 45]); mids = (bins[:-1] + bins[1:]) / 2
fig, axes = plt.subplots(1, 3, figsize=(W2, 2.35), sharey=True)
for ax, k, ttl in zip(axes, ['gas event', 'offset fault', 'gain fault'], ['(a) Gas step', '(b) Offset fault', '(c) Gain fault']):
    g = amp[amp.kind == k].copy(); g['bin'] = np.digitize(g.snr, bins) - 1
    for col, lab, c, m in [('lin', 'PIB-DT (linearised)', ORANGE, 's'), ('glr', 'GLR', AQUA, '^'), ('rf', 'Random forest', VIOLET, 'D'), ('exact', 'PIB-DT (exact)', BLUE, 'o')]:
        r = g.groupby('bin').apply(lambda h: pd.Series({'x': h.snr.median(), 'y': (h[col] == k).mean(), 'n': len(h)}), include_groups=False)
        r = r[r.n >= 10]; ax.plot(r.x, r.y * 100, marker=m, ms=5 if col == 'exact' else 3.4, mfc='none' if col == 'exact' else c, mew=1.1, color=c, lw=1.3, label=lab)
    ax.set_xscale('log'); ax.set_xlabel('True-change SNR, ‖Σ^(−1/2)E[d]‖'); ax.set_title(ttl); grid(ax)
    ax.axvline(30 if k == 'gain fault' else (38 if k == 'gas event' else 24), color=GRID, lw=.8, ls=':')
axes[0].set_ylabel('Correct-class recall (%)')
h_, l_ = axes[0].get_legend_handles_labels(); fig.legend(h_, l_, ncol=4, frameon=False, loc='lower center', bbox_to_anchor=(.5, -.04))
fig.tight_layout(w_pad=.6, rect=(0, .07, 1, 1))
save(fig, 'Fig06_recall_vs_snr')

# ---------------------------------------------------------------- Fig 7 W and noise sensitivity
wn = pd.read_csv(f'{R}/E5_window_noise.csv')
fig, axes = plt.subplots(1, 3, figsize=(W2, 2.3))
for sw, ax, xl, ttl in [('W', axes[0], 'Window length W (samples)', '(a) Accuracy vs window'), ('noise', axes[1], 'Noise multiplier (×nominal σ)', '(b) Accuracy vs noise')]:
    g = wn[wn.sweep == sw]
    for ev, c, m, lab in [('exact', BLUE, 'o', 'PIB-DT (exact)'), ('linear', ORANGE, 's', 'PIB-DT (linearised)')]:
        h = g[g.evidence == ev]; ax.plot(h.value, h.acc * 100, marker=m, ms=3.6, color=c, label=lab)
    h = g[g.evidence == 'exact']; ax.plot(h.value, h.glr_acc * 100, marker='^', ms=3.6, color=AQUA, label='GLR')
    h = g[g.evidence == 'exact']; ax.plot(h.value, h.joint_rej * 100, marker='x', ms=4, color=INK2, lw=1, ls='--', label='PIB-DT joint rejection')
    ax.set_xlabel(xl); ax.set_title(ttl); grid(ax); ax.set_ylim(74, 101)
axes[0].set_ylabel('Rate (%)'); axes[0].legend(frameon=False, loc='lower left')
ax = axes[2]; g = wn[(wn.sweep == 'noise') & (wn.evidence == 'exact')]
for col, c, m, lab in [('naive', ORANGE, 's', 'Fixed single'), ('diff', AQUA, '^', 'Differential'), ('twin', BLUE, 'o', 'PIB-DT')]:
    ax.plot(g.value, g[col + '_cov'] * 100, marker=m, ms=3.6, color=c, label=lab)
ax.axhline(95, color=INK2, ls='--', lw=.8); ax.text(6, 88, 'nominal 95%', ha='right', fontsize=6.6, color=INK2)
ax.set_xlabel('Noise multiplier (×nominal σ)'); ax.set_ylabel('Empirical 95% coverage (%)'); ax.set_title('(c) Interval coverage vs noise'); ax.set_ylim(0, 105); grid(ax)
ax.legend(frameon=False, loc='lower right')
fig.tight_layout(w_pad=.8)
save(fig, 'Fig07_window_noise')

# ---------------------------------------------------------------- Fig 8 gate OC + joint escape
oc = pd.read_csv(f'{R}/E7_gate_oc.csv'); je = pd.read_csv(f'{R}/E7_joint_escape.csv')
fig, axes = plt.subplots(1, 2, figsize=(W2, 2.4))
ax = axes[0]
for ev, c, m, lab in [('exact', BLUE, 'o', 'PIB-DT (exact)'), ('linear', ORANGE, 's', 'PIB-DT (linearised)')]:
    h = oc[oc.evidence == ev]; ax.plot(1 - h.alpha, h.false_reject * 100, marker=m, ms=3.6, color=c, label=lab)
ax.set_xscale('log'); ax.invert_xaxis(); ax.set_xlabel('Nominal gate level 1 − α'); ax.set_ylabel('False rejection of single faults (%)')
ax.set_title('(a) Gate operating characteristic'); grid(ax); ax.legend(frameon=False)
ax.text(.42, .45, 'joint-case rejection = 100%\nat every level shown', transform=ax.transAxes, fontsize=6.8, color=INK2)
ax = axes[1]; h = je[je.evidence == 'exact']
ax.plot(h.scale, h.reject * 100, marker='o', ms=3.6, color=BLUE, label='PIB-DT: abstain (unmodelled)')
ax.plot(h.scale, h.as_normal * 100, marker='s', ms=3.6, color=GRAY, label='PIB-DT: labelled normal')
ax.plot(h.scale, (h.as_gas + h.as_gain + h.as_offset) * 100, marker='^', ms=3.6, color=ORANGE, label='PIB-DT: single-cause label')
ax.plot(h.scale, (h.glr_as_gas + h.glr_as_gain) * 100, marker='D', ms=3.4, color=AQUA, ls='--', label='GLR: single-cause label')
ax.set_xscale('log'); ax.set_xlabel('Compound-fault amplitude (fraction of nominal)'); ax.set_ylabel('Share of joint episodes (%)')
ax.set_title('(b) Compound fault vs amplitude'); grid(ax); ax.legend(frameon=False, fontsize=6.4, loc='center left')
fig.tight_layout(w_pad=1.2)
save(fig, 'Fig08_gate')

# ---------------------------------------------------------------- Fig 9 scenario RMSE and coverage
sc = pd.read_csv(f'{R}/T_scenario_with_CI.csv')
names = ['normal', 'gas event', 'offset fault', 'gain fault', 'joint']; lab = ['Normal', 'Gas', 'Offset', 'Gain', 'Gas + gain']
fig, axes = plt.subplots(1, 2, figsize=(W2, 2.45))
xs = np.arange(5)
for j, (m, c, ln) in enumerate([('naive', ORANGE, 'Fixed single channel'), ('diff', AQUA, 'Differential only'), ('twin', BLUE, 'PIB-DT')]):
    g = sc[sc.estimator == m].set_index('scenario').loc[names]
    axes[0].bar(xs + (j - 1) * .26, g.RMSE, .24, color=c, label=ln, edgecolor='white', lw=.6)
    axes[0].errorbar(xs + (j - 1) * .26, g.RMSE, yerr=[g.RMSE - g.RMSE_lo, g.RMSE_hi - g.RMSE], fmt='none', ecolor=INK, lw=.7, capsize=1.5)
    axes[1].errorbar(xs + (j - 1) * .12, g.coverage * 100, yerr=[(g.coverage - g.cov_lo) * 100, (g.cov_hi - g.coverage) * 100], fmt='o', ms=3.8, color=c, lw=.9, capsize=1.5, label=ln)
axes[0].set_xticks(xs, lab); axes[0].set_ylabel('Concentration RMSE (ppm)'); axes[0].set_title('(a) RMSE with 95% bootstrap CI'); grid(axes[0])
axes[0].legend(frameon=False, loc='upper left')
axes[1].axhline(95, color=INK2, ls='--', lw=.8); axes[1].set_xticks(xs, lab); axes[1].set_ylabel('Empirical 95% coverage (%)')
axes[1].set_title('(b) Coverage with 95% Wilson CI'); axes[1].set_ylim(-3, 105); grid(axes[1])
fig.tight_layout(w_pad=1.2)
save(fig, 'Fig09_quantification')

# ---------------------------------------------------------------- Fig 10 reliability + calibration mismatch
rel = pd.read_csv(f'{R}/T_reliability.csv'); cmm = pd.read_csv(f'{R}/E8_calibration_mismatch.csv')
fig, axes = plt.subplots(1, 2, figsize=(W2, 2.45))
ax = axes[0]
for m, c, mk_, ln in [('naive', ORANGE, 's', 'Fixed single channel'), ('diff', AQUA, '^', 'Differential only'), ('twin', BLUE, 'o', 'PIB-DT')]:
    h = rel[rel.estimator == m]; ax.plot(h.nominal * 100, h.empirical * 100, marker=mk_, ms=3.6, color=c, label=ln)
ax.plot([50, 99], [50, 99], color=INK2, ls='--', lw=.8); ax.set_xlabel('Nominal interval level (%)'); ax.set_ylabel('Empirical coverage (%)')
ax.set_title('(a) Interval reliability (700 episodes)'); grid(ax); ax.legend(frameon=False, loc='upper left'); ax.set_ylim(0, 102); ax.set_xlim(47, 101)
ax = axes[1]; t = cmm[cmm.estimator == 'twin']
for mdl, c, mk_, ln in [('fixed 1.5%', BLUE, 'o', 'assumed σ_cal = 1.5%'), ('matched', ORANGE, 's', 'assumed σ_cal = true σ_cal')]:
    h = t[t.model == mdl]; ax.plot(h.true_cal_sd * 100, h.coverage * 100, marker=mk_, ms=3.6, color=c, label=ln)
ax.axhline(95, color=INK2, ls='--', lw=.8); ax.set_xlabel('True per-episode calibration SD (%)'); ax.set_ylabel('PIB-DT 95% coverage (%)')
ax.set_title('(b) Calibration-prior mismatch'); grid(ax); ax.legend(frameon=False, loc='lower left'); ax.set_ylim(40, 102)
fig.tight_layout(w_pad=1.2)
save(fig, 'Fig10_reliability')

# ---------------------------------------------------------------- Fig 11 rolling posteriors
fig, axes = plt.subplots(2, 2, figsize=(W2, 3.6), sharex=True, sharey=True)
cols = [GRAY, BLUE, ORANGE, AQUA]
for ax, k in zip(axes.flat, MODES):
    d = eps[k]; W = 10; P = []; T = []
    for kk in range(2 * W - 1, 120):
        r = bayes_contrast(d, EX, (kk - 2 * W + 1, kk - W + 1), (kk - W + 1, kk + 1)); P.append(r['p']); T.append(kk)
    P = np.array(P)
    for m in range(4): ax.plot(T, P[:, m], color=cols[m], lw=1.3, label=MODES[m])
    ax.axvline(50, color=INK2, ls='--', lw=.8); ax.set_title(k[0].upper() + k[1:] + ' episode'); grid(ax); ax.set_ylim(-.03, 1.03)
axes[0, 0].legend(ncol=4, frameon=False, loc='lower left', bbox_to_anchor=(0, 1.1))
for a in axes[1]: a.set_xlabel('Index of latest acquisition')
for a in axes[:, 0]: a.set_ylabel('Posterior probability')
fig.subplots_adjust(hspace=.38, wspace=.08)
save(fig, 'Fig11_posteriors')

# ---------------------------------------------------------------- Fig 12 latency + concentration trace
lat = pd.read_csv(f'{R}/E10_latency.csv')
fig, axes = plt.subplots(1, 2, figsize=(W2, 2.45), gridspec_kw={'width_ratios': [1, 1.5]})
ax = axes[0]; h = lat[(lat.evidence == 'exact') & (lat.kind != 'normal')]
for j, (k, c) in enumerate([('gas event', BLUE), ('offset fault', ORANGE), ('gain fault', AQUA)]):
    v = h[h.kind == k].delay.value_counts().sort_index().reindex(range(0, 5), fill_value=0)
    ax.bar(np.arange(5) + (j - 1) * .26, v.values, .24, color=c, label=k, edgecolor='white', lw=.5)
ax.set_xlabel('Detection delay after onset (samples)'); ax.set_ylabel('Episodes (of 100)'); ax.set_title('(a) Online detection delay'); grid(ax); ax.legend(frameon=False)
ax = axes[1]; d = eps['gain fault']; E = []; L = []; U = []; T = []
for end in range(10, 120):
    mu, sd = estimates(d, Cfg(), end - 10, end); E.append(mu[2]); L.append(mu[2] - 1.96 * sd[2]); U.append(mu[2] + 1.96 * sd[2]); T.append(end)
ax.axvspan(50, 119, color=GRAY, alpha=.12, lw=0)
ax.fill_between(T, L, U, color=BLUE, alpha=.18, lw=0, label='nominal 95% interval')
ax.plot(d['t'], d['c'], color=INK, ls='--', lw=1.1, label='true concentration')
ax.plot(T, E, color=BLUE, lw=1.4, label='PIB-DT calibrated estimate')
naive = []
for end in range(10, 120):
    mu, sd = estimates(d, Cfg(), end - 10, end); naive.append(mu[1])
ax.plot(T, naive, color=AQUA, lw=1.1, label='differential only')
ax.set_xlabel('Acquisition index'); ax.set_ylabel('Concentration (ppm)'); ax.set_title('(b) Estimate during a gain fault (shaded)'); grid(ax)
ax.legend(frameon=False, fontsize=6.6, loc='lower left')
fig.tight_layout(w_pad=1.2)
save(fig, 'Fig12_latency_trace')
print('figures done')
