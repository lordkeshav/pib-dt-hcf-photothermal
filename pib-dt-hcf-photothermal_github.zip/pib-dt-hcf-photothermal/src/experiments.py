"""Extended experiments for the revised PIB-DT manuscript (all synthetic)."""
import sys, json, time
import os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import numpy as np, pandas as pd
from dataclasses import replace
from scipy.stats import binomtest, chi2
from pibdt import *
from pibdt import _reduced

OUT = os.path.join(HERE, '..', 'data', 'results')
os.makedirs(OUT, exist_ok=True)
SUM = {}
BASE = Cfg()
EXACT = Cfg(evidence='exact')


def wilson(k, n, z=1.959964):
    p = k / n; den = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / den; half = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return centre - half, centre + half


def mcnemar(a, b):
    """exact McNemar on paired boolean correctness arrays"""
    n01 = int(np.sum(a & ~b)); n10 = int(np.sum(~a & b))
    n = n01 + n10
    p = 1.0 if n == 0 else binomtest(n01, n, .5).pvalue
    return n01, n10, p


t0 = time.time()
# ---------------------------------------------------------------- E0/E1 main benchmark (original seed)
df_lin = run_benchmark(BASE)
df_ex = run_benchmark(EXACT)
df_lin.to_csv(f'{OUT}/E1_main_linear_episodes.csv', index=False)
df_ex.to_csv(f'{OUT}/E1_main_exact_episodes.csv', index=False)

# ML baselines trained on an independent seed
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline


def ml_dataset(c, seed, N, kinds=MODES):
    rng = np.random.default_rng(seed); rx = np.random.default_rng(seed + 7)
    X, y = [], []
    for k in kinds:
        for j in range(N):
            d = make_episode(k, rng, c, rx); X.append(ml_features(d, c)); y.append(k)
    return np.array(X), np.array(y)

Xtr, ytr = ml_dataset(BASE, 11, 500)
models = {'Logistic regression': make_pipeline(StandardScaler(), LogisticRegression(max_iter=5000)),
          'Random forest': RandomForestClassifier(n_estimators=300, random_state=0, n_jobs=2),
          'MLP (32-32)': make_pipeline(StandardScaler(), MLPClassifier((32, 32), max_iter=3000, random_state=0))}
for nm, mdl in models.items():
    mdl.fit(Xtr, ytr)
Xte, yte = ml_dataset(BASE, 20261025, 140, kinds=KINDS)   # identical draws to main test set
assert (yte == df_lin.kind.values).all()
for nm, mdl in models.items():
    df_lin[nm] = mdl.predict(Xte); df_ex[nm] = df_lin[nm]

# classification table with CIs
rows = []
methods = [('Fixed on-line threshold', 'single', df_lin), ('Reference-differential threshold', 'differential', df_lin),
           ('GLR structured residual', 'glr', df_lin)] + [(nm, nm, df_lin) for nm in models] + \
          [('PIB-DT (linearised, original)', 'bayes', df_lin), ('PIB-DT (exact gain evidence)', 'bayes', df_ex)]
p_lin = df_lin[df_lin.kind.isin(MODES)]; p_ex = df_ex[df_ex.kind.isin(MODES)]
for name, col, d in methods:
    p = d[d.kind.isin(MODES)]
    m = class_metrics(d, col); k = int((p[col] == p.kind).sum()); lo, hi = wilson(k, len(p))
    j = d[d.kind == 'joint']; kj = int((j[col] == 'unmodelled').sum())
    rec = {mm: (p.loc[p.kind == mm, col] == mm).mean() for mm in MODES}
    rows.append(dict(method=name, correct=k, n=len(p), accuracy=m['accuracy'], acc_lo=lo, acc_hi=hi,
                     macro_f1=m['macro_f1'], false_alarm=m['false_alarm'], joint_rejected=kj,
                     joint_mode_label=j[col].value_counts().idxmax(), **{f'recall_{mm}': v for mm, v in rec.items()}))
cls = pd.DataFrame(rows); cls.to_csv(f'{OUT}/T_classification_with_CI.csv', index=False)
# McNemar vs exact twin
ref = (p_ex.bayes == p_ex.kind).values
mc = []
for name, col, d in methods[:-1]:
    p = d[d.kind.isin(MODES)]; a = (p[col] == p.kind).values
    n01, n10, pv = mcnemar(ref, a)
    mc.append(dict(method=name, twin_right_other_wrong=n01, twin_wrong_other_right=n10, p_exact=pv))
pd.DataFrame(mc).to_csv(f'{OUT}/T_mcnemar.csv', index=False)
# joint-case labels by method
jl = {name: d[d.kind == 'joint'][col].value_counts().to_dict() for name, col, d in methods}
SUM['joint_labels'] = jl

# confusion matrices
conf = {}
for name, col, d in methods:
    p = d[d.kind.isin(MODES)]
    conf[name] = [[float(np.mean(p.loc[p.kind == a, col] == b)) for b in MODES + ['unmodelled']] for a in MODES]
SUM['confusion'] = conf

# quantification with bootstrap CIs
brng = np.random.default_rng(20261026)
B = 2000; n = len(df_lin)
idx = brng.integers(0, n, (B, n))
qrows = []
for m, name in [('naive', 'Fixed single channel'), ('diff', 'Differential only'), ('twin', 'PIB-DT calibrated inverse')]:
    e = (df_lin[m] - df_lin.truth_ppm).values; cov = np.abs(e) <= 1.96 * df_lin[m + '_sd'].values
    rm = np.sqrt((e[idx] ** 2).mean(1)); ma = np.abs(e[idx]).mean(1)
    k = int(cov.sum()); lo, hi = wilson(k, n)
    qrows.append(dict(method=name, RMSE=np.sqrt(np.mean(e ** 2)), RMSE_lo=np.quantile(rm, .025), RMSE_hi=np.quantile(rm, .975),
                      MAE=np.mean(np.abs(e)), MAE_lo=np.quantile(ma, .025), MAE_hi=np.quantile(ma, .975), bias=e.mean(),
                      coverage=cov.mean(), cov_lo=lo, cov_hi=hi, covered=k, median_width=np.median(3.92 * df_lin[m + '_sd']),
                      mean_abs_z=np.mean(np.abs(e) / df_lin[m + '_sd'].values)))
q = pd.DataFrame(qrows); q.to_csv(f'{OUT}/T_quantification_with_CI.csv', index=False)
ed = (df_lin['diff'] - df_lin.truth_ppm).values; et = (df_lin['twin'] - df_lin.truth_ppm).values
red = 1 - np.sqrt((et[idx] ** 2).mean(1)) / np.sqrt((ed[idx] ** 2).mean(1))
D = ed ** 2 - et ** 2
SUM['rmse_reduction_vs_diff'] = dict(point=1 - np.sqrt(np.mean(et ** 2)) / np.sqrt(np.mean(ed ** 2)), lo=np.quantile(red, .025), hi=np.quantile(red, .975))
# replicate original bootstrap exactly
b_rng = np.random.default_rng(20261026); mb = []
for i in range(2000):
    ii = b_rng.integers(0, len(D), len(D)); mb.append(D[ii].mean())
SUM['paired_mse_gain'] = dict(point=D.mean(), lo=np.quantile(mb, .025), hi=np.quantile(mb, .975))
from scipy.stats import wilcoxon
SUM['wilcoxon_abs_err_twin_vs_diff'] = float(wilcoxon(np.abs(et), np.abs(ed)).pvalue)

# scenario table with CIs
srows = []
for k in KINDS:
    g = df_lin[df_lin.kind == k]; ng = len(g); ii = brng.integers(0, ng, (B, ng))
    for m in ['naive', 'diff', 'twin']:
        e = (g[m] - g.truth_ppm).values; cov = np.abs(e) <= 1.96 * g[m + '_sd'].values
        rm = np.sqrt((e[ii] ** 2).mean(1)); lo, hi = wilson(int(cov.sum()), ng)
        srows.append(dict(scenario=k, estimator=m, RMSE=np.sqrt(np.mean(e ** 2)), RMSE_lo=np.quantile(rm, .025),
                          RMSE_hi=np.quantile(rm, .975), bias=e.mean(), coverage=cov.mean(), cov_lo=lo, cov_hi=hi))
pd.DataFrame(srows).to_csv(f'{OUT}/T_scenario_with_CI.csv', index=False)

# reliability of intervals: coverage at many nominal levels
from scipy.stats import norm
levels = np.array([.5, .6, .7, .8, .9, .95, .99])
rel = []
for m in ['naive', 'diff', 'twin']:
    z = np.abs(df_lin[m] - df_lin.truth_ppm) / df_lin[m + '_sd']
    for L in levels:
        rel.append(dict(estimator=m, nominal=L, empirical=np.mean(z <= norm.ppf(.5 + L / 2))))
pd.DataFrame(rel).to_csv(f'{OUT}/T_reliability.csv', index=False)
print('E1 done', time.time() - t0)

# ---------------------------------------------------------------- E2 seed replication
rep = []
for i in range(1, 31):
    s = 20270000 + i
    for nm, c in [('linear', BASE), ('exact', EXACT)]:
        d = run_benchmark(c, seed=s)
        mb_ = class_metrics(d, 'bayes'); mg = class_metrics(d, 'glr')
        r = dict(seed=s, evidence=nm, acc=mb_['accuracy'], f1=mb_['macro_f1'], fa=mb_['false_alarm'], joint_rej=mb_['joint_reject'],
                 glr_acc=mg['accuracy'])
        for m in ['naive', 'diff', 'twin']:
            qm = quant_metrics(d, m); r[f'{m}_rmse'] = qm['RMSE']; r[f'{m}_cov'] = qm['coverage']
        rep.append(r)
rep = pd.DataFrame(rep); rep.to_csv(f'{OUT}/E2_seed_replication.csv', index=False)
_a = rep.drop(columns='seed').groupby('evidence').agg(['mean', 'std', 'min', 'max']).round(5)
_a.columns = ['_'.join(x) for x in _a.columns]
SUM['seed_replication'] = _a.to_dict(orient='index')
print('E2 done', time.time() - t0)

# ---------------------------------------------------------------- E3 ablations (nominal)
abl = []
def ablate(name, c, inc_cal=True, inc_pump=True, col='bayes'):
    d = run_benchmark(c)
    if not (inc_cal and inc_pump):
        rng = np.random.default_rng(20261025); rx = np.random.default_rng(20261025 + 7); sds = []; mus = []
        for k in KINDS:
            for j in range(140):
                e = make_episode(k, rng, c, rx); mu, sd = estimates(e, c, include_cal=inc_cal, include_pump=inc_pump)
                sds.append(sd[2]); mus.append(mu[2])
        d['twin_sd'] = sds; d['twin'] = mus
    m = class_metrics(d, col); qm = quant_metrics(d, 'twin')
    abl.append(dict(variant=name, accuracy=m['accuracy'], macro_f1=m['macro_f1'], false_alarm=m['false_alarm'],
                    joint_reject=m['joint_reject'], gain_recall=np.mean(d.loc[d.kind == 'gain fault', col] == 'gain fault'),
                    offset_recall=np.mean(d.loc[d.kind == 'offset fault', col] == 'offset fault'),
                    gas_recall=np.mean(d.loc[d.kind == 'gas event', col] == 'gas event'),
                    twin_RMSE=qm['RMSE'], twin_cov=qm['coverage'], twin_width=qm['width']))
ablate('Full PIB-DT, exact gain evidence', EXACT)
ablate('Linearised gain evidence (original)', BASE)
ablate('Diagonal covariance (cross-term ignored)', replace(EXACT, cov='diag'))
ablate('No adequacy gate', replace(EXACT, gate=False))
ablate('No temperature normalisation', replace(EXACT, temp_norm=False))
ablate('No off-resonance reference channel', replace(EXACT, channels='no_ref'))
ablate('No pump-monitor channel', replace(EXACT, channels='no_pump'))
ablate('Interval without calibration term', EXACT, inc_cal=False)
ablate('Interval without pump-noise term', EXACT, inc_pump=False)
pd.DataFrame(abl).to_csv(f'{OUT}/T_ablation.csv', index=False)
print('E3 done', time.time() - t0)

# ---------------------------------------------------------------- E4 amplitude / SNR sweep
def true_snr(d, c, kind):
    delta, Sigma, V, gf = _reduced(d, c, c.pre, c.post)
    g = d['cal'] * np.exp(d['ell'][c.pre[0]])
    if kind == 'gas event': e = np.array([c.H0 * g * d['dc'], 0, 0])
    elif kind == 'offset fault': e = np.array([0, d['db'], 0])
    else: e = np.array([c.H0 * g * d['c0'] * (np.exp(d['dg']) - 1), 0, d['dg']])
    return float(np.sqrt(e @ np.linalg.solve(Sigma, e)))

scales = [.03, .05, .08, .11, .15, .2, .3, .5, .75, 1.0]
amp = []
for kind, key in [('gas event', 'gas'), ('offset fault', 'offset'), ('gain fault', 'gain')]:
    for s in scales:
        sc = {'gas': 1., 'offset': 1., 'gain': 1.}; sc[key] = s
        cl = replace(BASE, amp_scale=sc); ce = replace(EXACT, amp_scale=sc)
        rng = np.random.default_rng(int(3e7 + s * 1000) + len(key)); rx = np.random.default_rng(5)
        for j in range(140):
            d = make_episode(kind, rng, cl, rx)
            bl = bayes_contrast(d, cl); be = bayes_contrast(d, ce)
            f = ml_features(d, cl)
            amp.append(dict(kind=kind, scale=s, snr=true_snr(d, cl, kind), lin=bl['label'], exact=be['label'],
                            glr=glr_classifier(d, cl), rf=models['Random forest'].predict(f[None])[0],
                            lr=models['Logistic regression'].predict(f[None])[0],
                            mlp=models['MLP (32-32)'].predict(f[None])[0]))
amp = pd.DataFrame(amp); amp.to_csv(f'{OUT}/E4_amplitude_sweep.csv', index=False)
print('E4 done', time.time() - t0)

# ---------------------------------------------------------------- E5 window length and noise
wn = []
for W in [3, 4, 5, 6, 8, 10, 12, 15]:
    for nm, c in [('linear', BASE), ('exact', EXACT)]:
        cc = replace(c, W=W, pre=(50 - W, 50), post=(52, 52 + W))
        d = run_benchmark(cc, seed=40000 + W)
        m = class_metrics(d, 'bayes'); mg = class_metrics(d, 'glr')
        wn.append(dict(sweep='W', value=W, evidence=nm, acc=m['accuracy'], f1=m['macro_f1'], fa=m['false_alarm'],
                       joint_rej=m['joint_reject'], glr_acc=mg['accuracy'], glr_fa=mg['false_alarm']))
for nmult in [.5, 1., 1.5, 2., 3., 4., 6.]:
    for nm, c in [('linear', BASE), ('exact', EXACT)]:
        cc = replace(c, noise_mult=nmult)
        d = run_benchmark(cc, seed=50000 + int(nmult * 10))
        m = class_metrics(d, 'bayes'); mg = class_metrics(d, 'glr')
        r = dict(sweep='noise', value=nmult, evidence=nm, acc=m['accuracy'], f1=m['macro_f1'], fa=m['false_alarm'],
                 joint_rej=m['joint_reject'], glr_acc=mg['accuracy'], glr_fa=mg['false_alarm'])
        for mm in ['naive', 'diff', 'twin']:
            qm = quant_metrics(d, mm); r[f'{mm}_rmse'] = qm['RMSE']; r[f'{mm}_cov'] = qm['coverage']
        wn.append(r)
pd.DataFrame(wn).to_csv(f'{OUT}/E5_window_noise.csv', index=False)
print('E5 done', time.time() - t0)

# ---------------------------------------------------------------- E6 prior sensitivity (at noise x3 where it matters)
pr = []
for nmult in [1., 3.]:
    for pi0 in [.25, .5, .7, .9, .97, .99]:
        r_ = (1 - pi0) / 3
        cc = replace(EXACT, noise_mult=nmult, prior=(pi0, r_, r_, r_))
        d = run_benchmark(cc, seed=60000 + int(nmult))
        m = class_metrics(d, 'bayes')
        pr.append(dict(noise_mult=nmult, factor='pi0', value=pi0, acc=m['accuracy'], fa=m['false_alarm'], joint_rej=m['joint_reject'],
                       miss=np.mean(d.loc[d.kind.isin(MODES[1:]), 'bayes'] == 'normal')))
    for f in [.25, .5, 1., 2., 4.]:
        cc = replace(EXACT, noise_mult=nmult, scales=(0., 30. * f, .14 * f, .21 * f))
        d = run_benchmark(cc, seed=60000 + int(nmult))
        m = class_metrics(d, 'bayes')
        pr.append(dict(noise_mult=nmult, factor='tau_scale', value=f, acc=m['accuracy'], fa=m['false_alarm'], joint_rej=m['joint_reject'],
                       miss=np.mean(d.loc[d.kind.isin(MODES[1:]), 'bayes'] == 'normal')))
pd.DataFrame(pr).to_csv(f'{OUT}/E6_prior_sensitivity.csv', index=False)
print('E6 done', time.time() - t0)

# ---------------------------------------------------------------- E7 gate operating characteristic + joint escape
oc = []
for nm, d in [('linear', df_lin), ('exact', df_ex)]:
    p = d[d.kind.isin(MODES[1:])]; j = d[d.kind == 'joint']
    for a in [.9, .95, .99, .995, .999, .9999, .99999]:
        thr = chi2.ppf(a, 2)
        oc.append(dict(evidence=nm, alpha=a, threshold=thr, false_reject=np.mean(p.chi2 > thr), joint_reject=np.mean(j.chi2 > thr)))
pd.DataFrame(oc).to_csv(f'{OUT}/E7_gate_oc.csv', index=False)
je = []
for s in [.02, .05, .1, .15, .2, .3, .5, .75, 1.]:
    sc = {'gas': s, 'offset': 1., 'gain': s}
    for nm, c in [('linear', BASE), ('exact', EXACT)]:
        cc = replace(c, amp_scale=sc)
        d = run_benchmark(cc, seed=70000 + int(s * 100), kinds=['joint'])
        vc = d.bayes.value_counts(normalize=True).to_dict()
        je.append(dict(scale=s, evidence=nm, reject=vc.get('unmodelled', 0), as_gas=vc.get('gas event', 0),
                       as_gain=vc.get('gain fault', 0), as_normal=vc.get('normal', 0), as_offset=vc.get('offset fault', 0),
                       glr_as_gas=np.mean(d.glr == 'gas event'), glr_as_gain=np.mean(d.glr == 'gain fault')))
pd.DataFrame(je).to_csv(f'{OUT}/E7_joint_escape.csv', index=False)
print('E7 done', time.time() - t0)

# ---------------------------------------------------------------- E8 calibration-prior mismatch and temperature robustness
cm = []
for true_sd in [0., .005, .01, .015, .02, .03, .05]:
    for assumed in ['fixed 1.5%', 'matched']:
        cc = replace(EXACT, cal_sd_true=true_sd, cal_sd_model=.015 if assumed == 'fixed 1.5%' else true_sd)
        d = run_benchmark(cc, seed=80000 + int(true_sd * 1000))
        for mm in ['naive', 'diff', 'twin']:
            qm = quant_metrics(d, mm)
            cm.append(dict(true_cal_sd=true_sd, model=assumed, estimator=mm, RMSE=qm['RMSE'], coverage=qm['coverage'], width=qm['width']))
pd.DataFrame(cm).to_csv(f'{OUT}/E8_calibration_mismatch.csv', index=False)
tr = []
for amp_ in [(2., 5.), (10., 10.), (20., 20.), (40., 40.)]:
    for tn in [True, False]:
        cc = replace(EXACT, temp_amp=amp_, temp_norm=tn)
        d = run_benchmark(cc, seed=90000 + int(amp_[1]))
        m = class_metrics(d, 'bayes'); qm = quant_metrics(d, 'twin')
        tr.append(dict(case='temp_amplitude', value=amp_[1], temp_norm=tn, acc=m['accuracy'], joint_rej=m['joint_reject'], twin_RMSE=qm['RMSE'], twin_cov=qm['coverage']))
for sdT in [0., .5, 1., 2., 5.]:
    cc = replace(EXACT, temp_amp=(20., 20.), temp_meas_sd=sdT)
    d = run_benchmark(cc, seed=91000 + int(sdT * 10))
    m = class_metrics(d, 'bayes'); qm = quant_metrics(d, 'twin')
    tr.append(dict(case='temp_sensor_sd', value=sdT, temp_norm=True, acc=m['accuracy'], joint_rej=m['joint_reject'], twin_RMSE=qm['RMSE'], twin_cov=qm['coverage']))
for el in [0., 150., 300., 450., 600.]:
    cc = replace(EXACT, temp_amp=(20., 20.), ELOW_model=el)
    d = run_benchmark(cc, seed=92000)
    m = class_metrics(d, 'bayes'); qm = quant_metrics(d, 'twin')
    tr.append(dict(case='Elow_model', value=el, temp_norm=True, acc=m['accuracy'], joint_rej=m['joint_reject'], twin_RMSE=qm['RMSE'], twin_cov=qm['coverage']))
pd.DataFrame(tr).to_csv(f'{OUT}/E8_temperature.csv', index=False)
print('E8 done', time.time() - t0)

# ---------------------------------------------------------------- E9 ML out-of-distribution amplitude test
ood = []
for s in [.3, .5, 1., 1.5, 2.]:
    cc = replace(BASE, amp_scale={'gas': s, 'offset': s, 'gain': s}); ce = replace(EXACT, amp_scale={'gas': s, 'offset': s, 'gain': s})
    rng = np.random.default_rng(int(1e6 + s * 100)); rx = np.random.default_rng(3)
    res = {k: [] for k in ['exact', 'glr'] + list(models)}; truth = []
    for k in MODES:
        for j in range(140):
            d = make_episode(k, rng, cc, rx); truth.append(k)
            res['exact'].append(bayes_contrast(d, ce)['label']); res['glr'].append(glr_classifier(d, cc))
            f = ml_features(d, cc)[None]
            for nm, mdl in models.items(): res[nm].append(mdl.predict(f)[0])
    truth = np.array(truth)
    for k_, v in res.items():
        ood.append(dict(scale=s, method=k_, acc=np.mean(np.array(v) == truth)))
pd.DataFrame(ood).to_csv(f'{OUT}/E9_ml_ood.csv', index=False)
print('E9 done', time.time() - t0)

# ---------------------------------------------------------------- E10 online latency (rolling windows)
lat = []
rng = np.random.default_rng(1234567); rx = np.random.default_rng(1)
for kind in MODES:
    for j in range(100):
        d = make_episode(kind, rng, BASE, rx)
        for nm, c in [('linear', BASE), ('exact', EXACT)]:
            W = c.W; labels = []
            for k in range(2 * W - 1, c.nsteps):
                labels.append((k, bayes_contrast(d, c, (k - 2 * W + 1, k - W + 1), (k - W + 1, k + 1))['label']))
            pre_fa = np.mean([l != 'normal' for k, l in labels if k < c.onset])
            first = next(((k, l) for k, l in labels if k >= c.onset and l != 'normal'), (np.nan, 'none'))
            lat.append(dict(kind=kind, trial=j, evidence=nm, pre_onset_alarm_rate=pre_fa, delay=first[0] - c.onset if first[0] == first[0] else np.nan,
                            first_label=first[1], any_alarm_normal=np.mean([l != 'normal' for k, l in labels]) if kind == 'normal' else np.nan))
lat = pd.DataFrame(lat); lat.to_csv(f'{OUT}/E10_latency.csv', index=False)
print('E10 done', time.time() - t0)

# ---------------------------------------------------------------- E11 timing
rng = np.random.default_rng(5); d = make_episode('gain fault', rng, BASE)
tm = {}
for nm, c in [('linear', BASE), ('exact', EXACT)]:
    for _ in range(50): bayes_contrast(d, c)
    t = time.perf_counter(); n = 3000
    for _ in range(n): bayes_contrast(d, c)
    tm[nm] = (time.perf_counter() - t) / n * 1e6
t = time.perf_counter()
for _ in range(3000): glr_classifier(d, BASE)
tm['glr'] = (time.perf_counter() - t) / 3000 * 1e6
f = ml_features(d, BASE)[None]
for nm, mdl in models.items():
    t = time.perf_counter()
    for _ in range(300): mdl.predict(f)
    tm[nm] = (time.perf_counter() - t) / 300 * 1e6
SUM['timing_us_per_decision'] = tm
import platform
SUM['environment'] = dict(python=platform.python_version(), numpy=np.__version__, platform=platform.platform(), processor=platform.processor(), cpus=os.cpu_count())
import scipy, sklearn, matplotlib
SUM['environment'].update(scipy=scipy.__version__, sklearn=sklearn.__version__, pandas=pd.__version__, matplotlib=matplotlib.__version__)
SUM['runtime_s'] = time.time() - t0
json.dump(SUM, open(f'{OUT}/summary.json', 'w'), indent=1, default=lambda o: float(o) if isinstance(o, (np.floating, np.integer)) else str(o))
rows = [dict(method=me, true_class=t, predicted_class=p, fraction=SUM['confusion'][me][i][j])
        for me in SUM['confusion'] for i, t in enumerate(MODES) for j, p in enumerate(MODES + ['unmodelled'])]
pd.DataFrame(rows).to_csv(f'{OUT}/T_confusion.csv', index=False)
pd.DataFrame([dict(method=me, label=k, count=v) for me, d in SUM['joint_labels'].items() for k, v in d.items()]).to_csv(f'{OUT}/T_joint_labels.csv', index=False)
pd.DataFrame([('rmse_reduction_vs_diff', *[SUM['rmse_reduction_vs_diff'][k] for k in ('point', 'lo', 'hi')]),
              ('paired_mse_gain_ppm2', *[SUM['paired_mse_gain'][k] for k in ('point', 'lo', 'hi')]),
              ('wilcoxon_p_abs_error_twin_vs_diff', SUM['wilcoxon_abs_err_twin_vs_diff'], None, None)],
             columns=['statistic', 'value', 'ci_low', 'ci_high']).to_csv(f'{OUT}/T_statistics.csv', index=False)
pd.DataFrame(list(SUM['timing_us_per_decision'].items()), columns=['method', 'microseconds_per_decision']).to_csv(f'{OUT}/T_timing.csv', index=False)
print(json.dumps(SUM['timing_us_per_decision'], indent=1)); print('ALL DONE', time.time() - t0)
