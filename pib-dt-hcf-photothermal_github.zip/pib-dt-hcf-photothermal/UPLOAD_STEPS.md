# How to upload this repository to GitHub

Do not commit this file if you don't want it in the repo (delete it after uploading).

## Option A — GitHub website (no Git needed)
1. Sign in to github.com → **New repository**.
2. Name: `pib-dt-hcf-photothermal`; choose Public or Private; do **not** add a README, .gitignore or license (they are already here) → **Create repository**.
3. On the empty repo page click **uploading an existing file**.
4. Drag in the whole unzipped folder contents (`README.md`, `requirements.txt`, `LICENSE`, `CITATION.cff`, `.gitignore`, `src/`, `data/`). Folders keep their structure when dragged in Chrome/Edge.
   - `.gitignore` is a hidden file; if your file manager hides it, enable "show hidden files" or create it on GitHub with **Add file → Create new file**.
5. Commit message: `Initial release: PIB-DT code and synthetic datasets` → **Commit changes**.

## Option B — Git command line
```bash
cd pib-dt-hcf-photothermal
git init
git add .
git commit -m "Initial release: PIB-DT code and synthetic datasets"
git branch -M main
git remote add origin https://github.com/<your-username>/pib-dt-hcf-photothermal.git
git push -u origin main
```

## After uploading
- Replace `<your-username>` in `README.md` and `CITATION.cff`, and `[Author names]` in `LICENSE` and `CITATION.cff`.
- Optional: connect the repo to Zenodo (zenodo.org → GitHub → enable the repo → create a GitHub release) to get a DOI for the manuscript's data-availability statement.
