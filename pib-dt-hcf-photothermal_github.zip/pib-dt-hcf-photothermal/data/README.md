# Data dictionary

All files are comma-separated (CSV) with a header row. **All data are synthetic** and were produced by the scripts in `src/` with fixed random seeds.

## Common terms

| Term | Meaning |
|---|---|
| `kind` / `scenario` | True scenario: `normal`, `gas event`, `offset fault`, `gain fault`, `joint` (compound gas step + gain fault) |
| Class labels | `normal`, `gas event`, `offset fault`, `gain fault`, `unmodelled` (abstention by the adequacy gate) |
| `naive` | Fixed single-channel concentration estimator |
| `diff` | Differential (off-resonance reference) estimator |
| `twin` | PIB-DT calibrated estimator (gain-corrected, with calibration uncertainty) |
| `linear` / `exact` | PIB-DT with linearized gain evidence (original) or exact Gauss–Hermite gain evidence (revision) |
| Coverage | Fraction of episodes whose nominal 95% interval contains the true concentration |
| `_lo`, `_hi` | Lower and upper limits of a 95% confidence interval (Wilson for proportions, bootstrap for RMSE/MAE) |
| Units | Concentration in ppm; phase in mrad; rates and accuracies as fractions (0–1) unless stated |

---

## `original/` — original benchmark (seed 20261025)

### `monte_carlo_trials.csv` (700 rows, one per episode)

| Column | Description |
|---|---|
| `kind` | True scenario |
| `trial` | Episode index within the scenario (0–139) |
| `bayes` | PIB-DT label (linearized evidence) |
| `single` | Label from the fixed on-line threshold rule |
| `differential` | Label from the reference-differential threshold rule |
| `correct` | `True` if `bayes` equals `kind` |
| `postprob` | Posterior probability of the winning mode |
| `truth_ppm` | True mean concentration in the estimation window (indices 75–84), ppm |
| `naive`, `diff`, `twin` | Concentration estimates, ppm |
| `naive_sd`, `diff_sd`, `twin_sd` | Standard uncertainty of each estimate, ppm (95% interval = estimate ± 1.96·SD) |
| `chi2` | Adequacy statistic Q of the winning mode |

### `scenario_metrics.csv` (15 rows)

| Column | Description |
|---|---|
| `scenario` | True scenario |
| `estimator` | `naive`, `diff` or `twin` |
| `RMSE_ppm` | Root-mean-square error, ppm |
| `coverage95` | Empirical coverage of nominal 95% intervals |

---

## `results/` — extended experiments (revision)

### Episode-level files

**`E1_main_linear_episodes.csv`, `E1_main_exact_episodes.csv`** (700 rows each; same episodes as `original/`, linearized vs exact evidence)

Same columns as `monte_carlo_trials.csv`, plus:

| Column | Description |
|---|---|
| `glr` | Label from the GLR structured-residual classifier |
| `top` | Mode with the highest posterior before the adequacy gate |
| `dc`, `db`, `dg` | Drawn amplitudes of the gas step (ppm), offset step (mrad) and log-gain step (applied only in the matching scenarios) |
| `p_normal`, `p_gas event`, `p_offset fault`, `p_gain fault` | Posterior mode probabilities |

**`E4_amplitude_sweep.csv`** (4200 rows: 3 fault types × 10 amplitude scales × 140 episodes)

| Column | Description |
|---|---|
| `kind` | Fault type |
| `scale` | Fault amplitude as a fraction of the nominal range |
| `snr` | Signal-to-noise ratio of the true mean contrast, ‖Σ^(−1/2) E[d]‖ |
| `lin`, `exact`, `glr`, `rf`, `lr`, `mlp` | Predicted labels: PIB-DT linearized, PIB-DT exact, GLR, random forest, logistic regression, MLP |

**`E10_latency.csv`** (800 rows: 4 classes × 100 episodes × 2 evidence types)

| Column | Description |
|---|---|
| `kind`, `trial`, `evidence` | Scenario, episode index, `linear`/`exact` |
| `pre_onset_alarm_rate` | Fraction of rolling windows before the onset (index 50) with a non-normal label |
| `delay` | Acquisitions from onset to the first non-normal label (empty if none) |
| `first_label` | Label at first detection (`none` if never detected) |
| `any_alarm_normal` | Normal episodes only: fraction of all rolling windows with a non-normal label |

### Summary tables

| File | Rows | Columns |
|---|---|---|
| `T_classification_with_CI.csv` | 8 methods | `method`, `correct`, `n`, `accuracy`, `acc_lo`, `acc_hi`, `macro_f1`, `false_alarm`, `joint_rejected` (count of 140), `joint_mode_label` (most frequent compound label), per-class `recall_*` |
| `T_mcnemar.csv` | 7 | Exact McNemar test against the exact-evidence PIB-DT: `twin_right_other_wrong`, `twin_wrong_other_right`, `p_exact` |
| `T_confusion.csv` | 160 | `method`, `true_class`, `predicted_class`, `fraction` (row-normalized) |
| `T_joint_labels.csv` | – | Labels assigned to the 140 compound episodes: `method`, `label`, `count` |
| `T_ablation.csv` | 9 variants | `variant`, `accuracy`, `macro_f1`, `false_alarm`, `joint_reject`, `gain_recall`, `offset_recall`, `gas_recall`, `twin_RMSE`, `twin_cov`, `twin_width` (median 95% width, ppm) |
| `T_quantification_with_CI.csv` | 3 estimators | `RMSE`, `MAE` with `_lo`/`_hi`, `bias`, `coverage` with `cov_lo`/`cov_hi`, `covered` (count of 700), `median_width`, `mean_abs_z` (mean of \|error\|/SD) |
| `T_scenario_with_CI.csv` | 15 | `scenario`, `estimator`, `RMSE` with CI, `bias`, `coverage` with CI |
| `T_reliability.csv` | 21 | `estimator`, `nominal` interval level, `empirical` coverage |
| `T_statistics.csv` | 3 | RMSE reduction vs differential, paired MSE gain (ppm²), Wilcoxon p-value: `statistic`, `value`, `ci_low`, `ci_high` |
| `T_timing.csv` | 6 | `method`, `microseconds_per_decision` (Python, 2-vCPU VM) |

### Sweep and stress-test files

| File | Columns |
|---|---|
| `E2_seed_replication.csv` | `seed`, `evidence`, `acc`, `f1`, `fa` (false alarm), `joint_rej`, `glr_acc`, `naive_rmse`, `naive_cov`, `diff_rmse`, `diff_cov`, `twin_rmse`, `twin_cov` |
| `E5_window_noise.csv` | `sweep` (`W` or `noise`), `value`, `evidence`, `acc`, `f1`, `fa`, `joint_rej`, `glr_acc`, `glr_fa`, and for the noise sweep RMSE/coverage of each estimator |
| `E6_prior_sensitivity.csv` | `noise_mult`, `factor` (`pi0` or `tau_scale`), `value`, `acc`, `fa`, `joint_rej`, `miss` (faults labelled normal) |
| `E7_gate_oc.csv` | `evidence`, `alpha` (gate level), `threshold` (χ² value), `false_reject` (single-cause faults rejected), `joint_reject` |
| `E7_joint_escape.csv` | `scale` (compound amplitude fraction), `evidence`, share labelled `reject`/`as_gas`/`as_gain`/`as_normal`/`as_offset`, and GLR shares `glr_as_gas`/`glr_as_gain` |
| `E8_calibration_mismatch.csv` | `true_cal_sd`, `model` (`fixed 1.5%` or `matched`), `estimator`, `RMSE`, `coverage`, `width` |
| `E8_temperature.csv` | `case` (`temp_amplitude` K, `temp_sensor_sd` K, `Elow_model` cm⁻¹), `value`, `temp_norm`, `acc`, `joint_rej`, `twin_RMSE`, `twin_cov` |
| `E9_ml_ood.csv` | `scale` (amplitude relative to training range), `method`, `acc` |

## Seeds

| Data | Seed |
|---|---|
| Main benchmark (`original/`, `E1`, `T_*`) | 20261025; bootstrap 20261026 |
| Replication (`E2`) | 20270001–20270030 |
| ML training set | 11 |
| Sweeps (`E4`–`E10`) | Fixed per configuration in `src/experiments.py` |
